package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.i18n.AppLanguage
import com.example.i18n.LocalAppStrings
import com.example.i18n.MatchIQLocalization
import com.example.ui.MainTab
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.screens.CreateMatchScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LiveMatchScreen
import com.example.ui.screens.MatchDetailScreen
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.PlayerProfileScreen
import com.example.ui.screens.PlayersScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TeamScreen
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MatchIQTheme
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MatchIQViewModel = viewModel()
      val prefs by viewModel.preferences.collectAsState()
      val appLanguage = if (prefs.language == "ar") AppLanguage.ARABIC else AppLanguage.ENGLISH

      MatchIQTheme(darkTheme = prefs.isDarkMode) {
        MatchIQLocalization(language = appLanguage) {
          MatchIQApp(viewModel = viewModel)
        }
      }
    }
  }
}

@Composable
fun MatchIQApp(viewModel: MatchIQViewModel) {
  val s = LocalAppStrings.current
  val currentScreen by viewModel.currentScreen.collectAsState()
  val currentTab by viewModel.currentTab.collectAsState()

  when (val screen = currentScreen) {
    is Screen.LiveMatch -> {
      LiveMatchScreen(viewModel = viewModel)
    }
    is Screen.MatchDetail -> {
      MatchDetailScreen(matchId = screen.matchId, viewModel = viewModel)
    }
    is Screen.PlayerProfile -> {
      PlayerProfileScreen(playerId = screen.playerId, viewModel = viewModel)
    }
    is Screen.CreateMatch -> {
      CreateMatchScreen(viewModel = viewModel)
    }
    is Screen.CreateTeam -> {
      TeamScreen(viewModel = viewModel)
    }
    Screen.MainTabs -> {
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
          NavigationBar(
            containerColor = DarkSurface,
            contentColor = Color.White
          ) {
            NavigationBarItem(
              selected = currentTab == MainTab.DASHBOARD,
              onClick = { viewModel.setTab(MainTab.DASHBOARD) },
              icon = { Icon(Icons.Default.Dashboard, contentDescription = s.dashboard) },
              label = { Text(s.dashboard, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_dashboard")
            )
            NavigationBarItem(
              selected = currentTab == MainTab.MATCHES,
              onClick = { viewModel.setTab(MainTab.MATCHES) },
              icon = { Icon(Icons.Default.SportsSoccer, contentDescription = s.matches) },
              label = { Text(s.matches, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_matches")
            )
            NavigationBarItem(
              selected = currentTab == MainTab.TEAM,
              onClick = { viewModel.setTab(MainTab.TEAM) },
              icon = { Icon(Icons.Default.Group, contentDescription = s.team) },
              label = { Text(s.team, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_team")
            )
            NavigationBarItem(
              selected = currentTab == MainTab.PLAYERS,
              onClick = { viewModel.setTab(MainTab.PLAYERS) },
              icon = { Icon(Icons.Default.Person, contentDescription = s.players) },
              label = { Text(s.players, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_players")
            )
            NavigationBarItem(
              selected = currentTab == MainTab.REPORTS,
              onClick = { viewModel.setTab(MainTab.REPORTS) },
              icon = { Icon(Icons.Default.Assessment, contentDescription = s.reports) },
              label = { Text(s.reports, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_reports")
            )
            NavigationBarItem(
              selected = currentTab == MainTab.SETTINGS,
              onClick = { viewModel.setTab(MainTab.SETTINGS) },
              icon = { Icon(Icons.Default.Settings, contentDescription = s.settings) },
              label = { Text(s.settings, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PitchGreenLight,
                selectedTextColor = PitchGreenLight,
                indicatorColor = PitchGreenPrimary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag("nav_tab_settings")
            )
          }
        }
      ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)
        when (currentTab) {
          MainTab.DASHBOARD -> DashboardScreen(viewModel = viewModel, modifier = modifier)
          MainTab.MATCHES -> MatchesScreen(viewModel = viewModel, modifier = modifier)
          MainTab.TEAM -> TeamScreen(viewModel = viewModel, modifier = modifier)
          MainTab.PLAYERS -> PlayersScreen(viewModel = viewModel, modifier = modifier)
          MainTab.REPORTS -> ReportsScreen(viewModel = viewModel, modifier = modifier)
          MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel, modifier = modifier)
        }
      }
    }
  }
}
