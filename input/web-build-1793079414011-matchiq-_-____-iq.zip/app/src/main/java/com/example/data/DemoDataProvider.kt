package com.example.data

import com.example.data.local.MatchEntity
import com.example.data.local.MatchEventEntity
import com.example.data.local.MatchNoteEntity
import com.example.data.local.PlayerEntity
import com.example.data.local.SubstitutionEntity
import com.example.data.local.TeamEntity
import com.example.model.AttackOrigin
import com.example.model.EventType
import com.example.model.GoalFinishType
import com.example.model.PitchZone
import com.example.model.Position
import com.example.model.PreferredFoot
import com.example.model.StatCategory

object DemoDataProvider {

  val demoTeam = TeamEntity(
    id = 1L,
    name = "Al-Mustaqbal FC (Future Athletic)",
    logoResName = "ic_matchiq_logo",
    ageCategory = "Senior League - Group A",
    season = "2026/2027",
    coachName = "Hassan Al-Husseini",
    defaultFormation = "4-3-3"
  )

  // 11 Starters + 7 Substitutes (18 players total, fictional professional names)
  val demoPlayers = listOf(
    // Goalkeeper (Starter)
    PlayerEntity(id = 1L, teamId = 1L, name = "Zaid Al-Najjar", shirtNumber = 1, position = Position.GK.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 0),
    // Defense (Starters)
    PlayerEntity(id = 2L, teamId = 1L, name = "Omar Al-Khatib", shirtNumber = 2, position = Position.RB.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 1),
    PlayerEntity(id = 3L, teamId = 1L, name = "Faris Mansour", shirtNumber = 4, position = Position.CB.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 2),
    PlayerEntity(id = 4L, teamId = 1L, name = "Tariq Salem", shirtNumber = 5, position = Position.CB.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = true, orderIndex = 3),
    PlayerEntity(id = 5L, teamId = 1L, name = "Nasser Al-Ghamdi", shirtNumber = 3, position = Position.LB.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = true, orderIndex = 4),
    // Midfield (Starters)
    PlayerEntity(id = 6L, teamId = 1L, name = "Sami Al-Harbi", shirtNumber = 6, position = Position.DM.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 5),
    PlayerEntity(id = 7L, teamId = 1L, name = "Ahmed Radi", shirtNumber = 10, position = Position.CM.name, preferredFoot = PreferredFoot.BOTH.name, isStarter = true, orderIndex = 6),
    PlayerEntity(id = 8L, teamId = 1L, name = "Youssef Qasim", shirtNumber = 8, position = Position.AM.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = true, orderIndex = 7),
    // Attack (Starters)
    PlayerEntity(id = 9L, teamId = 1L, name = "Mohammed Al-Bader", shirtNumber = 7, position = Position.RW.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = true, orderIndex = 8),
    PlayerEntity(id = 10L, teamId = 1L, name = "Ali Al-Fardan", shirtNumber = 9, position = Position.ST.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 9),
    PlayerEntity(id = 11L, teamId = 1L, name = "Karim Al-Sayed", shirtNumber = 11, position = Position.LW.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = true, orderIndex = 10),

    // Substitutes (7 Bench)
    PlayerEntity(id = 12L, teamId = 1L, name = "Hamza Al-Amri", shirtNumber = 22, position = Position.GK.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = false, orderIndex = 11),
    PlayerEntity(id = 13L, teamId = 1L, name = "Hassan Al-Bahrani", shirtNumber = 14, position = Position.CB.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = false, orderIndex = 12),
    PlayerEntity(id = 14L, teamId = 1L, name = "Bilal Al-Otaibi", shirtNumber = 16, position = Position.LB.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = false, orderIndex = 13),
    PlayerEntity(id = 15L, teamId = 1L, name = "Rami Al-Dossari", shirtNumber = 17, position = Position.CM.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = false, orderIndex = 14),
    PlayerEntity(id = 16L, teamId = 1L, name = "Majed Al-Mutairi", shirtNumber = 19, position = Position.AM.name, preferredFoot = PreferredFoot.BOTH.name, isStarter = false, orderIndex = 15),
    PlayerEntity(id = 17L, teamId = 1L, name = "Saad Al-Shehri", shirtNumber = 20, position = Position.RW.name, preferredFoot = PreferredFoot.RIGHT.name, isStarter = false, orderIndex = 16),
    PlayerEntity(id = 18L, teamId = 1L, name = "Khaled Al-Zahrani", shirtNumber = 21, position = Position.ST.name, preferredFoot = PreferredFoot.LEFT.name, isStarter = false, orderIndex = 17)
  )

  fun getDemoFinishedMatch(): MatchEntity {
    val threeDaysAgo = System.currentTimeMillis() - (3 * 24 * 60 * 60 * 1000L)
    return MatchEntity(
      id = 1L,
      teamId = 1L,
      opponentName = "Al-Ittihad Youth",
      competition = "Championship Round 4",
      matchDate = threeDaysAgo,
      venue = "Olympic Sports City",
      isHome = true,
      matchDurationMinutes = 90,
      formation = "4-3-3",
      ourScore = 3,
      opponentScore = 1,
      isFinished = true,
      isLive = false,
      currentMinute = 90,
      currentSecond = 0,
      currentHalf = 2,
      notes = "Dominant high-press performance in first half; conceded from a set-piece in min 62, then sealed the game with an incisive counter-attack."
    )
  }

  fun getDemoMatchEvents(matchId: Long): List<MatchEventEntity> {
    val events = mutableListOf<MatchEventEntity>()
    var eid = 1L

    fun addEv(p: PlayerEntity, type: EventType, min: Int, sec: Int = 15, half: Int = if (min <= 45) 1 else 2, zone: PitchZone? = null, notes: String = "", meta: String = "") {
      events.add(
        MatchEventEntity(
          id = eid++,
          matchId = matchId,
          playerId = p.id,
          playerName = p.name,
          playerShirtNumber = p.shirtNumber,
          playerPosition = p.position,
          eventType = type.name,
          category = type.category.name,
          matchMinute = min,
          matchSecond = sec,
          half = half,
          zone = zone?.name,
          notes = notes,
          metadataJson = meta
        )
      )
    }

    val p1Gk = demoPlayers[0]
    val p2Rb = demoPlayers[1]
    val p3Cb = demoPlayers[2]
    val p4Cb = demoPlayers[3]
    val p5Lb = demoPlayers[4]
    val p6Dm = demoPlayers[5]
    val p7Cm = demoPlayers[6]  // Ahmed #10
    val p8Am = demoPlayers[7]  // Youssef #8
    val p9Rw = demoPlayers[8]  // Mohammed #7
    val p10St = demoPlayers[9] // Ali #9
    val p11Lw = demoPlayers[10]// Karim #11
    val p15Sub = demoPlayers[14]// Rami #17

    // First Half events (0 - 45)
    addEv(p7Cm, EventType.PASS_COMPLETED, 2, 10, 1, PitchZone.MID_CENTER)
    addEv(p6Dm, EventType.TACKLE_WON, 4, 30, 1, PitchZone.MID_CENTER)
    addEv(p11Lw, EventType.SUCCESSFUL_DRIBBLE, 7, 12, 1, PitchZone.ATT_LEFT)
    addEv(p11Lw, EventType.CROSS_SUCCESSFUL, 7, 24, 1, PitchZone.ATT_LEFT)
    addEv(p10St, EventType.HEADER_SHOT, 7, 28, 1, PitchZone.ATT_CENTER)
    addEv(p10St, EventType.GOAL, 7, 29, 1, PitchZone.ATT_CENTER, meta = "{\"scorer\":\"Ali Al-Fardan\",\"assist\":\"Karim Al-Sayed\",\"finishType\":\"HEADER\",\"origin\":\"LEFT_WING\"}")
    addEv(p11Lw, EventType.ASSIST, 7, 29, 1, PitchZone.ATT_LEFT)

    addEv(p7Cm, EventType.KEY_PASS, 14, 40, 1, PitchZone.MID_CENTER)
    addEv(p9Rw, EventType.SHOT_ON_TARGET, 15, 0, 1, PitchZone.ATT_RIGHT)
    addEv(p1Gk, EventType.GK_SAVE, 19, 15, 1, PitchZone.DEF_CENTER)
    addEv(p3Cb, EventType.CLEARANCE, 22, 10, 1, PitchZone.DEF_CENTER)
    addEv(p7Cm, EventType.PASS_COMPLETED, 25, 45, 1, PitchZone.MID_CENTER)
    addEv(p7Cm, EventType.SUCCESSFUL_DRIBBLE, 28, 20, 1, PitchZone.MID_RIGHT)
    addEv(p7Cm, EventType.SHOT_ON_TARGET, 28, 30, 1, PitchZone.ATT_CENTER)
    addEv(p7Cm, EventType.GOAL, 28, 31, 1, PitchZone.ATT_CENTER, meta = "{\"scorer\":\"Ahmed Radi\",\"assist\":null,\"finishType\":\"RIGHT_FOOT\",\"origin\":\"CENTRAL\"}")

    addEv(p4Cb, EventType.INTERCEPTION, 33, 10, 1, PitchZone.DEF_CENTER)
    addEv(p8Am, EventType.PASS_COMPLETED, 37, 20, 1, PitchZone.MID_LEFT)
    addEv(p10St, EventType.BALL_LOST, 41, 15, 1, PitchZone.ATT_CENTER)
    addEv(p6Dm, EventType.YELLOW_CARD, 44, 2, 1, PitchZone.MID_CENTER)

    // Second Half events (46 - 90)
    addEv(p2Rb, EventType.TACKLE_WON, 48, 10, 2, PitchZone.DEF_RIGHT)
    addEv(p7Cm, EventType.PASS_COMPLETED, 52, 15, 2, PitchZone.MID_CENTER)
    addEv(p9Rw, EventType.SUCCESSFUL_DRIBBLE, 55, 30, 2, PitchZone.ATT_RIGHT)
    addEv(p1Gk, EventType.GK_GOAL_CONCEDED, 62, 10, 2, PitchZone.DEF_CENTER) // Opponent scores
    addEv(p1Gk, EventType.GK_DANGEROUS_SAVE, 68, 40, 2, PitchZone.DEF_CENTER)
    addEv(p6Dm, EventType.BALL_RECOVERY, 73, 12, 2, PitchZone.MID_CENTER)
    addEv(p8Am, EventType.THROUGH_BALL, 77, 45, 2, PitchZone.MID_CENTER)
    addEv(p15Sub, EventType.PROGRESSIVE_RUN, 82, 10, 2, PitchZone.ATT_RIGHT)
    addEv(p10St, EventType.GOAL, 84, 50, 2, PitchZone.ATT_CENTER, meta = "{\"scorer\":\"Ali Al-Fardan\",\"assist\":\"Ahmed Radi\",\"finishType\":\"RIGHT_FOOT\",\"origin\":\"COUNTER_ATTACK\"}")
    addEv(p7Cm, EventType.ASSIST, 84, 50, 2, PitchZone.MID_CENTER)
    addEv(p3Cb, EventType.BLOCK, 89, 10, 2, PitchZone.DEF_CENTER)

    return events
  }

  fun getDemoSubstitutions(matchId: Long): List<SubstitutionEntity> {
    return listOf(
      SubstitutionEntity(
        id = 1L,
        matchId = matchId,
        minute = 65,
        playerOutId = 8L,
        playerOutName = "Youssef Qasim",
        playerOutNumber = 8,
        playerInId = 15L,
        playerInName = "Rami Al-Dossari",
        playerInNumber = 17
      )
    )
  }

  fun getDemoMatchNotes(matchId: Long): List<MatchNoteEntity> {
    return listOf(
      MatchNoteEntity(id = 1L, matchId = matchId, minute = 15, noteText = "Excellent early pressing by front three, forced turnover leading to opening goal."),
      MatchNoteEntity(id = 2L, matchId = matchId, minute = 63, noteText = "Opponent switched to long direct balls. We adjusted midfield line deeper to protect space behind."),
      MatchNoteEntity(id = 3L, matchId = matchId, minute = 85, noteText = "Fast transition executed cleanly for third goal. Ahmed Radi's through-pass was decisive.")
    )
  }
}
