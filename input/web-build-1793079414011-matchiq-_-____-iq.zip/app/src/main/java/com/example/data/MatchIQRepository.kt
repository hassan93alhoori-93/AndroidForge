package com.example.data

import android.content.Context
import com.example.data.local.CoachPreferencesEntity
import com.example.data.local.MatchEntity
import com.example.data.local.MatchEventEntity
import com.example.data.local.MatchIQDatabase
import com.example.data.local.MatchNoteEntity
import com.example.data.local.PlayerEntity
import com.example.data.local.SubstitutionEntity
import com.example.data.local.TeamEntity
import com.example.i18n.AppLanguage
import com.example.model.ActivityPeriodStats
import com.example.model.AttackOrigin
import com.example.model.EventType
import com.example.model.GoalFinishType
import com.example.model.GoalMetadata
import com.example.model.PitchZone
import com.example.model.PlayerMatchStats
import com.example.model.Position
import com.example.model.StatCategory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MatchIQRepository(private val context: Context) {
  private val db = MatchIQDatabase.getInstance(context)
  private val teamDao = db.teamDao()
  private val playerDao = db.playerDao()
  private val matchDao = db.matchDao()
  private val matchEventDao = db.matchEventDao()
  private val substitutionDao = db.substitutionDao()
  private val matchNoteDao = db.matchNoteDao()
  private val preferencesDao = db.coachPreferencesDao()

  init {
    CoroutineScope(Dispatchers.IO).launch {
      initializeDefaultsIfEmpty()
    }
  }

  suspend fun initializeDefaultsIfEmpty() = withContext(Dispatchers.IO) {
    val existingTeam = teamDao.getFirstTeam()
    if (existingTeam == null) {
      seedDemoData()
    }
    val existingPrefs = preferencesDao.getPreferencesOnce()
    if (existingPrefs == null) {
      preferencesDao.savePreferences(
        CoachPreferencesEntity(
          id = 1,
          language = "en",
          isDarkMode = true,
          hapticFeedback = true,
          soundFeedback = false,
          quickStatsJson = DEFAULT_QUICK_STATS.joinToString(",") { it.name }
        )
      )
    }
  }

  suspend fun seedDemoData() = withContext(Dispatchers.IO) {
    val tId = teamDao.insertTeam(DemoDataProvider.demoTeam)
    val playersWithTeam = DemoDataProvider.demoPlayers.map { it.copy(teamId = tId) }
    playerDao.insertPlayers(playersWithTeam)

    val demoMatch = DemoDataProvider.getDemoFinishedMatch().copy(teamId = tId)
    val mId = matchDao.insertMatch(demoMatch)

    val events = DemoDataProvider.getDemoMatchEvents(mId)
    matchEventDao.insertEvents(events)

    DemoDataProvider.getDemoSubstitutions(mId).forEach {
      substitutionDao.insertSubstitution(it.copy(matchId = mId))
    }
    DemoDataProvider.getDemoMatchNotes(mId).forEach {
      matchNoteDao.insertNote(it.copy(matchId = mId))
    }
  }

  suspend fun clearAllData() = withContext(Dispatchers.IO) {
    db.clearAllTables()
    seedDemoData()
  }

  // Preferences
  fun getPreferences(): Flow<CoachPreferencesEntity?> = preferencesDao.getPreferences()

  suspend fun updateLanguage(lang: AppLanguage) = withContext(Dispatchers.IO) {
    val current = preferencesDao.getPreferencesOnce() ?: CoachPreferencesEntity()
    preferencesDao.savePreferences(current.copy(language = lang.code))
  }

  suspend fun updateDarkMode(isDark: Boolean) = withContext(Dispatchers.IO) {
    val current = preferencesDao.getPreferencesOnce() ?: CoachPreferencesEntity()
    preferencesDao.savePreferences(current.copy(isDarkMode = isDark))
  }

  suspend fun updateHaptic(enabled: Boolean) = withContext(Dispatchers.IO) {
    val current = preferencesDao.getPreferencesOnce() ?: CoachPreferencesEntity()
    preferencesDao.savePreferences(current.copy(hapticFeedback = enabled))
  }

  suspend fun updateQuickStats(stats: List<EventType>) = withContext(Dispatchers.IO) {
    val current = preferencesDao.getPreferencesOnce() ?: CoachPreferencesEntity()
    preferencesDao.savePreferences(current.copy(quickStatsJson = stats.joinToString(",") { it.name }))
  }

  // Teams
  fun getAllTeams(): Flow<List<TeamEntity>> = teamDao.getAllTeams()
  suspend fun getFirstTeam(): TeamEntity? = withContext(Dispatchers.IO) { teamDao.getFirstTeam() }
  suspend fun saveTeam(team: TeamEntity): Long = withContext(Dispatchers.IO) {
    if (team.id == 0L) teamDao.insertTeam(team) else { teamDao.updateTeam(team); team.id }
  }

  // Players
  fun getPlayersForTeam(teamId: Long): Flow<List<PlayerEntity>> = playerDao.getPlayersForTeam(teamId)
  suspend fun getPlayersForTeamList(teamId: Long): List<PlayerEntity> = withContext(Dispatchers.IO) {
    playerDao.getPlayersForTeamList(teamId)
  }
  suspend fun getPlayerById(id: Long): PlayerEntity? = withContext(Dispatchers.IO) { playerDao.getPlayerById(id) }
  suspend fun savePlayer(player: PlayerEntity): Long = withContext(Dispatchers.IO) {
    if (player.id == 0L) playerDao.insertPlayer(player) else { playerDao.updatePlayer(player); player.id }
  }
  suspend fun deletePlayer(id: Long) = withContext(Dispatchers.IO) { playerDao.deletePlayer(id) }

  // Matches
  fun getAllMatches(): Flow<List<MatchEntity>> = matchDao.getAllMatches()
  fun getLiveMatch(): Flow<MatchEntity?> = matchDao.getLiveMatch()
  suspend fun getLiveMatchOnce(): MatchEntity? = withContext(Dispatchers.IO) { matchDao.getLiveMatchOnce() }
  fun getLatestFinishedMatch(): Flow<MatchEntity?> = matchDao.getLatestFinishedMatch()
  suspend fun getLatestFinishedMatchOnce(): MatchEntity? = withContext(Dispatchers.IO) { matchDao.getLatestFinishedMatchOnce() }
  fun getMatchByIdFlow(id: Long): Flow<MatchEntity?> = matchDao.getMatchByIdFlow(id)
  suspend fun getMatchById(id: Long): MatchEntity? = withContext(Dispatchers.IO) { matchDao.getMatchById(id) }

  suspend fun createMatch(match: MatchEntity): Long = withContext(Dispatchers.IO) {
    matchDao.insertMatch(match)
  }

  suspend fun updateMatch(match: MatchEntity) = withContext(Dispatchers.IO) {
    matchDao.updateMatch(match)
  }

  suspend fun deleteMatch(id: Long) = withContext(Dispatchers.IO) {
    matchDao.deleteMatch(id)
  }

  // Live Match Actions
  suspend fun startMatch(teamId: Long, opponentName: String, competition: String, venue: String, isHome: Boolean, duration: Int): Long = withContext(Dispatchers.IO) {
    // End any existing live match
    val currentLive = matchDao.getLiveMatchOnce()
    if (currentLive != null) {
      matchDao.updateMatch(currentLive.copy(isLive = false))
    }

    val match = MatchEntity(
      teamId = teamId,
      opponentName = opponentName,
      competition = competition,
      venue = venue,
      isHome = isHome,
      matchDurationMinutes = duration,
      matchDate = System.currentTimeMillis(),
      isLive = true,
      isFinished = false,
      isPaused = false,
      currentMinute = 0,
      currentSecond = 0,
      currentHalf = 1
    )
    matchDao.insertMatch(match)
  }

  suspend fun recordEvent(
    matchId: Long,
    player: PlayerEntity,
    eventType: EventType,
    minute: Int,
    second: Int,
    half: Int,
    zone: PitchZone? = null,
    notes: String = "",
    goalMetadata: GoalMetadata? = null
  ): Long = withContext(Dispatchers.IO) {
    val metaJson = goalMetadata?.let {
      "{\"scorer\":\"${player.name}\",\"assist\":\"${it.assistPlayerName ?: ""}\",\"finishType\":\"${it.finishType.name}\",\"origin\":\"${it.origin.name}\"}"
    } ?: ""

    val event = MatchEventEntity(
      matchId = matchId,
      playerId = player.id,
      playerName = player.name,
      playerShirtNumber = player.shirtNumber,
      playerPosition = player.position,
      eventType = eventType.name,
      category = eventType.category.name,
      matchMinute = minute,
      matchSecond = second,
      half = half,
      zone = zone?.name,
      notes = notes,
      metadataJson = metaJson
    )

    val evId = matchEventDao.insertEvent(event)

    // If goal, increment our team score
    if (eventType == EventType.GOAL || eventType == EventType.HEADER_GOAL) {
      val match = matchDao.getMatchById(matchId)
      if (match != null) {
        matchDao.updateMatch(match.copy(ourScore = match.ourScore + 1))
      }

      // If there was an assist provider, record assist event for that player
      if (goalMetadata?.assistPlayerId != null && goalMetadata.assistPlayerId != player.id) {
        val assistPlayer = playerDao.getPlayerById(goalMetadata.assistPlayerId)
        if (assistPlayer != null) {
          matchEventDao.insertEvent(
            MatchEventEntity(
              matchId = matchId,
              playerId = assistPlayer.id,
              playerName = assistPlayer.name,
              playerShirtNumber = assistPlayer.shirtNumber,
              playerPosition = assistPlayer.position,
              eventType = EventType.ASSIST.name,
              category = StatCategory.ATTACK.name,
              matchMinute = minute,
              matchSecond = second,
              half = half,
              zone = zone?.name,
              notes = "Assist for ${player.name}'s goal"
            )
          )
        }
      }
    }

    evId
  }

  suspend fun recordOpponentGoal(matchId: Long, minute: Int, second: Int, half: Int) = withContext(Dispatchers.IO) {
    val match = matchDao.getMatchById(matchId)
    if (match != null) {
      matchDao.updateMatch(match.copy(opponentScore = match.opponentScore + 1))
    }
  }

  suspend fun undoLastEvent(matchId: Long): MatchEventEntity? = withContext(Dispatchers.IO) {
    val lastEvent = matchEventDao.getLastEventForMatch(matchId) ?: return@withContext null
    matchEventDao.deleteEventById(lastEvent.id)

    // If undone event was a goal, decrement score
    if (lastEvent.eventType == EventType.GOAL.name || lastEvent.eventType == EventType.HEADER_GOAL.name) {
      val match = matchDao.getMatchById(matchId)
      if (match != null && match.ourScore > 0) {
        matchDao.updateMatch(match.copy(ourScore = match.ourScore - 1))
      }
    }
    lastEvent
  }

  suspend fun deleteEvent(matchId: Long, eventId: Long) = withContext(Dispatchers.IO) {
    val events = matchEventDao.getEventsForMatchList(matchId)
    val target = events.find { it.id == eventId }
    if (target != null) {
      matchEventDao.deleteEventById(eventId)
      if (target.eventType == EventType.GOAL.name || target.eventType == EventType.HEADER_GOAL.name) {
        val match = matchDao.getMatchById(matchId)
        if (match != null && match.ourScore > 0) {
          matchDao.updateMatch(match.copy(ourScore = match.ourScore - 1))
        }
      }
    }
  }

  suspend fun recordSubstitution(
    matchId: Long,
    minute: Int,
    playerOut: PlayerEntity,
    playerIn: PlayerEntity
  ) = withContext(Dispatchers.IO) {
    substitutionDao.insertSubstitution(
      SubstitutionEntity(
        matchId = matchId,
        minute = minute,
        playerOutId = playerOut.id,
        playerOutName = playerOut.name,
        playerOutNumber = playerOut.shirtNumber,
        playerInId = playerIn.id,
        playerInName = playerIn.name,
        playerInNumber = playerIn.shirtNumber
      )
    )

    // Log substitution event
    matchEventDao.insertEvent(
      MatchEventEntity(
        matchId = matchId,
        playerId = playerIn.id,
        playerName = playerIn.name,
        playerShirtNumber = playerIn.shirtNumber,
        playerPosition = playerIn.position,
        eventType = "SUBSTITUTION_IN",
        category = "TACTICAL",
        matchMinute = minute,
        matchSecond = 0,
        notes = "Replaced #${playerOut.shirtNumber} ${playerOut.name}"
      )
    )
  }

  suspend fun addMatchNote(matchId: Long, minute: Int, text: String) = withContext(Dispatchers.IO) {
    matchNoteDao.insertNote(MatchNoteEntity(matchId = matchId, minute = minute, noteText = text))
  }

  fun getEventsForMatch(matchId: Long): Flow<List<MatchEventEntity>> = matchEventDao.getEventsForMatch(matchId)
  suspend fun getEventsForMatchList(matchId: Long): List<MatchEventEntity> = withContext(Dispatchers.IO) {
    matchEventDao.getEventsForMatchList(matchId)
  }
  suspend fun getSubstitutionsForMatchList(matchId: Long): List<SubstitutionEntity> = withContext(Dispatchers.IO) {
    substitutionDao.getSubstitutionsForMatchList(matchId)
  }
  suspend fun getEventsForPlayerList(playerId: Long): List<MatchEventEntity> = withContext(Dispatchers.IO) {
    matchEventDao.getEventsForPlayerList(playerId)
  }
  fun getSubstitutionsForMatch(matchId: Long): Flow<List<SubstitutionEntity>> = substitutionDao.getSubstitutionsForMatch(matchId)
  fun getNotesForMatch(matchId: Long): Flow<List<MatchNoteEntity>> = matchNoteDao.getNotesForMatch(matchId)

  // Calculations & Analytics
  suspend fun calculatePlayerStats(matchId: Long, player: PlayerEntity, matchDurationMinutes: Int): PlayerMatchStats = withContext(Dispatchers.IO) {
    val events = matchEventDao.getEventsForMatchList(matchId).filter { it.playerId == player.id }
    val subs = substitutionDao.getSubstitutionsForMatchList(matchId)

    // Determine minutes played
    val subOut = subs.find { it.playerOutId == player.id }
    val subIn = subs.find { it.playerInId == player.id }

    val minutesPlayed = when {
      subOut != null -> subOut.minute
      subIn != null -> (matchDurationMinutes - subIn.minute).coerceAtLeast(0)
      player.isStarter -> matchDurationMinutes
      else -> 0
    }

    var goals = 0
    var assists = 0
    var shots = 0
    var shotsOnTarget = 0
    var shotsOffTarget = 0
    var passesCompleted = 0
    var passesFailed = 0
    var keyPasses = 0
    var dribblesSuccessful = 0
    var dribblesFailed = 0
    var ballLosses = 0
    var ballRecoveries = 0
    var tacklesWon = 0
    var tacklesLost = 0
    var interceptions = 0
    var clearances = 0
    var blocks = 0
    var foulsCommitted = 0
    var foulsWon = 0
    var yellowCards = 0
    var redCards = 0
    var outOfPosition = 0
    var stayedInPosition = 0
    var gkSaves = 0
    var gkDangerousSaves = 0
    var gkGoalsConceded = 0

    events.forEach { ev ->
      when (ev.eventType) {
        EventType.GOAL.name, EventType.HEADER_GOAL.name -> goals++
        EventType.ASSIST.name -> assists++
        EventType.SHOT.name -> shots++
        EventType.SHOT_ON_TARGET.name -> shotsOnTarget++
        EventType.SHOT_OFF_TARGET.name -> shotsOffTarget++
        EventType.PASS_COMPLETED.name -> passesCompleted++
        EventType.PASS_FAILED.name -> passesFailed++
        EventType.KEY_PASS.name -> keyPasses++
        EventType.SUCCESSFUL_DRIBBLE.name -> dribblesSuccessful++
        EventType.FAILED_DRIBBLE.name -> dribblesFailed++
        EventType.BALL_LOST.name, EventType.DISPOSSESSED.name, EventType.BAD_TOUCH.name -> ballLosses++
        EventType.BALL_RECOVERY.name -> ballRecoveries++
        EventType.TACKLE_WON.name -> tacklesWon++
        EventType.TACKLE_LOST.name -> tacklesLost++
        EventType.INTERCEPTION.name -> interceptions++
        EventType.CLEARANCE.name -> clearances++
        EventType.BLOCK.name -> blocks++
        EventType.FOUL_COMMITTED.name -> foulsCommitted++
        EventType.FOUL_WON.name -> foulsWon++
        EventType.YELLOW_CARD.name -> yellowCards++
        EventType.RED_CARD.name -> redCards++
        EventType.OUT_OF_POSITION.name, EventType.LEFT_POSITION.name -> outOfPosition++
        EventType.STAYED_IN_POSITION.name, EventType.GOOD_POSITIONING.name -> stayedInPosition++
        EventType.GK_SAVE.name, EventType.GK_EASY_SAVE.name, EventType.GK_1ON1_SAVE.name -> gkSaves++
        EventType.GK_DANGEROUS_SAVE.name -> { gkSaves++; gkDangerousSaves++ }
        EventType.GK_GOAL_CONCEDED.name -> gkGoalsConceded++
      }
    }

    val isGk = player.position == Position.GK.name
    val match = matchDao.getMatchById(matchId)
    val cleanSheet = isGk && (match?.opponentScore ?: 0) == 0

    PlayerMatchStats(
      playerId = player.id,
      playerName = player.name,
      shirtNumber = player.shirtNumber,
      position = Position.valueOf(player.position),
      minutesPlayed = minutesPlayed,
      isStarting = player.isStarter,
      goals = goals,
      assists = assists,
      shots = shots,
      shotsOnTarget = shotsOnTarget,
      shotsOffTarget = shotsOffTarget,
      passesCompleted = passesCompleted,
      passesFailed = passesFailed,
      keyPasses = keyPasses,
      dribblesSuccessful = dribblesSuccessful,
      dribblesFailed = dribblesFailed,
      ballLosses = ballLosses,
      ballRecoveries = ballRecoveries,
      tacklesWon = tacklesWon,
      tacklesLost = tacklesLost,
      interceptions = interceptions,
      clearances = clearances,
      blocks = blocks,
      foulsCommitted = foulsCommitted,
      foulsWon = foulsWon,
      yellowCards = yellowCards,
      redCards = redCards,
      outOfPosition = outOfPosition,
      stayedInPosition = stayedInPosition,
      gkSaves = gkSaves,
      gkDangerousSaves = gkDangerousSaves,
      gkGoalsConceded = gkGoalsConceded,
      gkCleanSheet = cleanSheet
    )
  }

  suspend fun calculateActivityPeriods(matchId: Long, playerId: Long? = null): List<ActivityPeriodStats> = withContext(Dispatchers.IO) {
    val allEvents = matchEventDao.getEventsForMatchList(matchId)
    val events = if (playerId != null) allEvents.filter { it.playerId == playerId } else allEvents

    val intervals = listOf(
      Triple("0–15'", 0, 15),
      Triple("15–30'", 15, 30),
      Triple("30–45'", 30, 45),
      Triple("45–60'", 45, 60),
      Triple("60–75'", 60, 75),
      Triple("75–90+'", 75, 120)
    )

    intervals.map { (label, start, end) ->
      val periodEvents = events.filter { it.matchMinute in start until end }
      val total = periodEvents.size
      val ballLoss = periodEvents.count { it.eventType in listOf(EventType.BALL_LOST.name, EventType.DISPOSSESSED.name, EventType.BAD_TOUCH.name, EventType.PASS_FAILED.name) }
      val defActions = periodEvents.count { it.category == StatCategory.DEFENSE.name || it.eventType == EventType.BALL_RECOVERY.name }
      val offActions = periodEvents.count { it.category == StatCategory.ATTACK.name }
      val successful = periodEvents.count {
        it.eventType in listOf(
          EventType.PASS_COMPLETED.name, EventType.SUCCESSFUL_DRIBBLE.name, EventType.GOAL.name,
          EventType.KEY_PASS.name, EventType.TACKLE_WON.name, EventType.INTERCEPTION.name,
          EventType.BALL_RECOVERY.name, EventType.GK_SAVE.name
        )
      }
      val unsuccessful = total - successful

      ActivityPeriodStats(
        periodLabel = label,
        startMinute = start,
        endMinute = end,
        totalActions = total,
        successfulActions = successful,
        unsuccessfulActions = unsuccessful.coerceAtLeast(0),
        ballLosses = ballLoss,
        defensiveActions = defActions,
        offensiveActions = offActions
      )
    }
  }

  fun generateActivityTrendSummary(periods: List<ActivityPeriodStats>, isArabic: Boolean): String {
    if (periods.isEmpty() || periods.all { it.totalActions == 0 }) {
      return if (isArabic) "لا تتوفر تسجيلات كافية لتحليل فترات المباراة بعد." else "Not enough match event records to evaluate periods."
    }
    val firstHalfCount = periods.take(3).sumOf { it.totalActions }
    val secondHalfCount = periods.drop(3).sumOf { it.totalActions }
    val last15 = periods.lastOrNull()?.ballLosses ?: 0
    val peakPeriod = periods.maxByOrNull { it.totalActions }

    val sb = StringBuilder()
    if (isArabic) {
      if (peakPeriod != null && peakPeriod.totalActions > 0) {
        sb.append("• كانت أعلى وتيرة أحداث مسجلة في الفترة (${peakPeriod.periodLabel}) بإجمالي ${peakPeriod.totalActions} إجراء.\n")
      }
      if (secondHalfCount < firstHalfCount && firstHalfCount > 0) {
        sb.append("• انخفضت وتيرة الإجراءات المسجلة في الشوط الثاني ($secondHalfCount) مقارنة بالأول ($firstHalfCount).\n")
      } else if (secondHalfCount > firstHalfCount) {
        sb.append("• ارتفعت وتيرة الإجراءات المسجلة في الشوط الثاني ($secondHalfCount) مقارنة بالأول ($firstHalfCount).\n")
      }
      if (last15 >= 3) {
        sb.append("• سُجّل ازدياد في فقدان الكرة (${last15} مرات) خلال الدقائق الـ 15 الأخيرة.\n")
      }
    } else {
      if (peakPeriod != null && peakPeriod.totalActions > 0) {
        sb.append("• Highest recorded action volume occurred during ${peakPeriod.periodLabel} with ${peakPeriod.totalActions} events.\n")
      }
      if (secondHalfCount < firstHalfCount && firstHalfCount > 0) {
        sb.append("• Recorded match activity decreased in the 2nd half ($secondHalfCount actions) relative to the 1st half ($firstHalfCount actions).\n")
      } else if (secondHalfCount > firstHalfCount) {
        sb.append("• Recorded match activity intensified in the 2nd half ($secondHalfCount actions) relative to the 1st half ($firstHalfCount actions).\n")
      }
      if (last15 >= 3) {
        sb.append("• Ball losses increased during the final 15 minutes ($last15 recorded).\n")
      }
    }
    return sb.toString().trim()
  }

  suspend fun exportMatchCsv(matchId: Long): String = withContext(Dispatchers.IO) {
    val match = matchDao.getMatchById(matchId) ?: return@withContext ""
    val events = matchEventDao.getEventsForMatchList(matchId)
    val sb = StringBuilder()
    sb.append("MatchID,Date,Opponent,Score,EventID,Minute,Second,Half,PlayerNumber,PlayerName,Position,EventType,Category,Zone,Notes\n")
    events.forEach { e ->
      sb.append("${match.id},\"${match.competition}\",\"${match.opponentName}\",\"${match.ourScore}-${match.opponentScore}\",")
      sb.append("${e.id},${e.matchMinute},${e.matchSecond},${e.half},${e.playerShirtNumber},\"${e.playerName}\",${e.playerPosition},${e.eventType},${e.category},${e.zone ?: ""},\"${e.notes.replace("\"", "\"\"")}\"\n")
    }
    sb.toString()
  }

  suspend fun formatMatchReportText(matchId: Long, isArabic: Boolean): String = withContext(Dispatchers.IO) {
    val match = matchDao.getMatchById(matchId) ?: return@withContext ""
    val team = teamDao.getTeamById(match.teamId)
    val events = matchEventDao.getEventsForMatchList(matchId)
    val subs = substitutionDao.getSubstitutionsForMatchList(matchId)
    val notes = matchNoteDao.getNotesForMatch(matchId).firstOrNull() ?: emptyList()

    val totalShots = events.count { it.category == StatCategory.ATTACK.name && (it.eventType.contains("SHOT") || it.eventType.contains("GOAL")) }
    val shotsOnTarget = events.count { it.eventType == EventType.SHOT_ON_TARGET.name || it.eventType == EventType.GOAL.name }
    val passesComp = events.count { it.eventType == EventType.PASS_COMPLETED.name }
    val passesFail = events.count { it.eventType == EventType.PASS_FAILED.name }
    val totalPasses = passesComp + passesFail
    val passAcc = if (totalPasses > 0) (passesComp * 100f / totalPasses).toInt() else 0

    val sb = StringBuilder()
    if (isArabic) {
      sb.append("⚽ تقرير مباراة ماتش IQ | MATCHIQ\n")
      sb.append("═══════════════════════════════════\n")
      sb.append("الفريق: ${team?.name ?: "فريقنا"}\n")
      sb.append("المنافس: ${match.opponentName}\n")
      sb.append("النتيجة: ${match.ourScore} - ${match.opponentScore}\n")
      sb.append("البطولة: ${match.competition}\n")
      sb.append("الملعب: ${match.venue}\n")
      sb.append("التشكيلة: ${match.formation}\n\n")
      sb.append("📊 إحصائيات الفريق:\n")
      sb.append("• الأهداف: ${match.ourScore}\n")
      sb.append("• التسديدات: $totalShots (على المرمى: $shotsOnTarget)\n")
      sb.append("• التمريرات: $passesComp / $totalPasses ($passAcc% دقة)\n")
      sb.append("• التبديلات: ${subs.size}\n")
      sb.append("• إجمالي الأحداث المسجلة: ${events.size}\n\n")
      if (subs.isNotEmpty()) {
        sb.append("🔄 التبديلات:\n")
        subs.forEach { s ->
          sb.append("• د ${s.minute}: خروج #${s.playerOutNumber} ${s.playerOutName} ⬅ دخول #${s.playerInNumber} ${s.playerInName}\n")
        }
        sb.append("\n")
      }
      if (notes.isNotEmpty()) {
        sb.append("📝 ملاحظات المدرب:\n")
        notes.forEach { n ->
          sb.append("• د ${n.minute}: ${n.noteText}\n")
        }
      }
    } else {
      sb.append("⚽ MATCHIQ COACHING MATCH REPORT\n")
      sb.append("═══════════════════════════════════\n")
      sb.append("Team: ${team?.name ?: "Our Team"}\n")
      sb.append("Opponent: ${match.opponentName}\n")
      sb.append("Final Score: ${match.ourScore} - ${match.opponentScore}\n")
      sb.append("Competition: ${match.competition}\n")
      sb.append("Venue: ${match.venue}\n")
      sb.append("Formation: ${match.formation}\n\n")
      sb.append("📊 Team Statistics:\n")
      sb.append("• Goals: ${match.ourScore}\n")
      sb.append("• Shots: $totalShots (On target: $shotsOnTarget)\n")
      sb.append("• Passes: $passesComp / $totalPasses ($passAcc% accuracy)\n")
      sb.append("• Substitutions: ${subs.size}\n")
      sb.append("• Total Recorded Events: ${events.size}\n\n")
      if (subs.isNotEmpty()) {
        sb.append("🔄 Substitutions:\n")
        subs.forEach { s ->
          sb.append("• Min ${s.minute}': OUT #${s.playerOutNumber} ${s.playerOutName} ⬅ IN #${s.playerInNumber} ${s.playerInName}\n")
        }
        sb.append("\n")
      }
      if (notes.isNotEmpty()) {
        sb.append("📝 Coach Observations:\n")
        notes.forEach { n ->
          sb.append("• Min ${n.minute}': ${n.noteText}\n")
        }
      }
    }
    sb.toString()
  }

  companion object {
    val DEFAULT_QUICK_STATS = listOf(
      EventType.PASS_COMPLETED,
      EventType.PASS_FAILED,
      EventType.SHOT,
      EventType.SHOT_ON_TARGET,
      EventType.SUCCESSFUL_DRIBBLE,
      EventType.BALL_LOST,
      EventType.KEY_PASS,
      EventType.TACKLE_WON,
      EventType.INTERCEPTION,
      EventType.FOUL_COMMITTED,
      EventType.BALL_RECOVERY,
      EventType.GOAL
    )
  }
}
