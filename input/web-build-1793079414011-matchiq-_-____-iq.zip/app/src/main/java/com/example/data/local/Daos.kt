package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TeamDao {
  @Query("SELECT * FROM teams ORDER BY id ASC")
  fun getAllTeams(): Flow<List<TeamEntity>>

  @Query("SELECT * FROM teams WHERE id = :id LIMIT 1")
  suspend fun getTeamById(id: Long): TeamEntity?

  @Query("SELECT * FROM teams LIMIT 1")
  suspend fun getFirstTeam(): TeamEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTeam(team: TeamEntity): Long

  @Update
  suspend fun updateTeam(team: TeamEntity)

  @Query("DELETE FROM teams WHERE id = :id")
  suspend fun deleteTeam(id: Long)
}

@Dao
interface PlayerDao {
  @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY orderIndex ASC, shirtNumber ASC")
  fun getPlayersForTeam(teamId: Long): Flow<List<PlayerEntity>>

  @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY orderIndex ASC, shirtNumber ASC")
  suspend fun getPlayersForTeamList(teamId: Long): List<PlayerEntity>

  @Query("SELECT * FROM players WHERE id = :id LIMIT 1")
  suspend fun getPlayerById(id: Long): PlayerEntity?

  @Query("SELECT * FROM players WHERE teamId = :teamId AND isStarter = 1 ORDER BY orderIndex ASC")
  suspend fun getStartingXI(teamId: Long): List<PlayerEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPlayer(player: PlayerEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPlayers(players: List<PlayerEntity>)

  @Update
  suspend fun updatePlayer(player: PlayerEntity)

  @Query("DELETE FROM players WHERE id = :id")
  suspend fun deletePlayer(id: Long)
}

@Dao
interface MatchDao {
  @Query("SELECT * FROM matches ORDER BY matchDate DESC")
  fun getAllMatches(): Flow<List<MatchEntity>>

  @Query("SELECT * FROM matches WHERE isLive = 1 LIMIT 1")
  fun getLiveMatch(): Flow<MatchEntity?>

  @Query("SELECT * FROM matches WHERE isLive = 1 LIMIT 1")
  suspend fun getLiveMatchOnce(): MatchEntity?

  @Query("SELECT * FROM matches WHERE isFinished = 1 ORDER BY matchDate DESC LIMIT 1")
  fun getLatestFinishedMatch(): Flow<MatchEntity?>

  @Query("SELECT * FROM matches WHERE isFinished = 1 ORDER BY matchDate DESC LIMIT 1")
  suspend fun getLatestFinishedMatchOnce(): MatchEntity?

  @Query("SELECT * FROM matches WHERE id = :id LIMIT 1")
  suspend fun getMatchById(id: Long): MatchEntity?

  @Query("SELECT * FROM matches WHERE id = :id LIMIT 1")
  fun getMatchByIdFlow(id: Long): Flow<MatchEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMatch(match: MatchEntity): Long

  @Update
  suspend fun updateMatch(match: MatchEntity)

  @Query("DELETE FROM matches WHERE id = :id")
  suspend fun deleteMatch(id: Long)
}

@Dao
interface MatchEventDao {
  @Query("SELECT * FROM match_events WHERE matchId = :matchId ORDER BY id DESC")
  fun getEventsForMatch(matchId: Long): Flow<List<MatchEventEntity>>

  @Query("SELECT * FROM match_events WHERE matchId = :matchId ORDER BY id DESC")
  suspend fun getEventsForMatchList(matchId: Long): List<MatchEventEntity>

  @Query("SELECT * FROM match_events WHERE playerId = :playerId ORDER BY exactTimestamp DESC")
  fun getEventsForPlayer(playerId: Long): Flow<List<MatchEventEntity>>

  @Query("SELECT * FROM match_events WHERE playerId = :playerId")
  suspend fun getEventsForPlayerList(playerId: Long): List<MatchEventEntity>

  @Query("SELECT * FROM match_events WHERE matchId = :matchId ORDER BY id DESC LIMIT 1")
  suspend fun getLastEventForMatch(matchId: Long): MatchEventEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEvent(event: MatchEventEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEvents(events: List<MatchEventEntity>)

  @Query("DELETE FROM match_events WHERE id = :id")
  suspend fun deleteEventById(id: Long)

  @Query("DELETE FROM match_events WHERE matchId = :matchId")
  suspend fun deleteEventsForMatch(matchId: Long)
}

@Dao
interface SubstitutionDao {
  @Query("SELECT * FROM substitutions WHERE matchId = :matchId ORDER BY minute ASC")
  fun getSubstitutionsForMatch(matchId: Long): Flow<List<SubstitutionEntity>>

  @Query("SELECT * FROM substitutions WHERE matchId = :matchId ORDER BY minute ASC")
  suspend fun getSubstitutionsForMatchList(matchId: Long): List<SubstitutionEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSubstitution(sub: SubstitutionEntity): Long
}

@Dao
interface MatchNoteDao {
  @Query("SELECT * FROM match_notes WHERE matchId = :matchId ORDER BY minute ASC, timestamp ASC")
  fun getNotesForMatch(matchId: Long): Flow<List<MatchNoteEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNote(note: MatchNoteEntity): Long

  @Query("DELETE FROM match_notes WHERE id = :id")
  suspend fun deleteNote(id: Long)
}

@Dao
interface CoachPreferencesDao {
  @Query("SELECT * FROM coach_preferences WHERE id = 1 LIMIT 1")
  fun getPreferences(): Flow<CoachPreferencesEntity?>

  @Query("SELECT * FROM coach_preferences WHERE id = 1 LIMIT 1")
  suspend fun getPreferencesOnce(): CoachPreferencesEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun savePreferences(prefs: CoachPreferencesEntity)
}
