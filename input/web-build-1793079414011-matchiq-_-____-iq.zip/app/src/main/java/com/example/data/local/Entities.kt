package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.model.EventType
import com.example.model.PitchZone
import com.example.model.Position
import com.example.model.PreferredFoot

@Entity(tableName = "teams")
data class TeamEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val logoResName: String = "ic_matchiq_logo",
  val ageCategory: String = "Senior / First Team",
  val season: String = "2026/2027",
  val coachName: String = "Coach",
  val defaultFormation: String = "4-3-3"
)

@Entity(
  tableName = "players",
  foreignKeys = [
    ForeignKey(
      entity = TeamEntity::class,
      parentColumns = ["id"],
      childColumns = ["teamId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("teamId")]
)
data class PlayerEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val teamId: Long,
  val name: String,
  val shirtNumber: Int,
  val position: String = Position.CM.name, // Position enum name
  val preferredFoot: String = PreferredFoot.RIGHT.name,
  val notes: String = "",
  val isActive: Boolean = true,
  val isStarter: Boolean = false,
  val orderIndex: Int = 0
)

@Entity(
  tableName = "matches",
  foreignKeys = [
    ForeignKey(
      entity = TeamEntity::class,
      parentColumns = ["id"],
      childColumns = ["teamId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("teamId")]
)
data class MatchEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val teamId: Long,
  val opponentName: String,
  val competition: String = "League Match",
  val matchDate: Long = System.currentTimeMillis(),
  val venue: String = "Main Stadium",
  val isHome: Boolean = true,
  val matchDurationMinutes: Int = 90,
  val formation: String = "4-3-3",
  val ourScore: Int = 0,
  val opponentScore: Int = 0,
  val isFinished: Boolean = false,
  val isLive: Boolean = false,
  val currentMinute: Int = 0,
  val currentSecond: Int = 0,
  val currentHalf: Int = 1,
  val isPaused: Boolean = false,
  val notes: String = ""
)

@Entity(
  tableName = "match_events",
  foreignKeys = [
    ForeignKey(
      entity = MatchEntity::class,
      parentColumns = ["id"],
      childColumns = ["matchId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("matchId"), Index("playerId")]
)
data class MatchEventEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val matchId: Long,
  val playerId: Long,
  val playerName: String,
  val playerShirtNumber: Int,
  val playerPosition: String,
  val eventType: String, // EventType.name
  val category: String,  // StatCategory.name
  val matchMinute: Int,
  val matchSecond: Int = 0,
  val exactTimestamp: Long = System.currentTimeMillis(),
  val half: Int = 1,
  val zone: String? = null, // PitchZone.name
  val notes: String = "",
  val metadataJson: String = "" // For goal assist, type, origin
)

@Entity(
  tableName = "substitutions",
  foreignKeys = [
    ForeignKey(
      entity = MatchEntity::class,
      parentColumns = ["id"],
      childColumns = ["matchId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("matchId")]
)
data class SubstitutionEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val matchId: Long,
  val minute: Int,
  val playerOutId: Long,
  val playerOutName: String,
  val playerOutNumber: Int,
  val playerInId: Long,
  val playerInName: String,
  val playerInNumber: Int,
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(
  tableName = "match_notes",
  foreignKeys = [
    ForeignKey(
      entity = MatchEntity::class,
      parentColumns = ["id"],
      childColumns = ["matchId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("matchId")]
)
data class MatchNoteEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val matchId: Long,
  val minute: Int,
  val noteText: String,
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "coach_preferences")
data class CoachPreferencesEntity(
  @PrimaryKey val id: Int = 1,
  val language: String = "en", // "en" or "ar"
  val isDarkMode: Boolean = true,
  val hapticFeedback: Boolean = true,
  val soundFeedback: Boolean = false,
  val quickStatsJson: String = "" // Comma separated EventType names
)
