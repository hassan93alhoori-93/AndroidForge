package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    TeamEntity::class,
    PlayerEntity::class,
    MatchEntity::class,
    MatchEventEntity::class,
    SubstitutionEntity::class,
    MatchNoteEntity::class,
    CoachPreferencesEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class MatchIQDatabase : RoomDatabase() {
  abstract fun teamDao(): TeamDao
  abstract fun playerDao(): PlayerDao
  abstract fun matchDao(): MatchDao
  abstract fun matchEventDao(): MatchEventDao
  abstract fun substitutionDao(): SubstitutionDao
  abstract fun matchNoteDao(): MatchNoteDao
  abstract fun coachPreferencesDao(): CoachPreferencesDao

  companion object {
    @Volatile
    private var INSTANCE: MatchIQDatabase? = null

    fun getInstance(context: Context): MatchIQDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          MatchIQDatabase::class.java,
          "matchiq_database.db"
        )
          .fallbackToDestructiveMigration(dropAllTables = true)
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
