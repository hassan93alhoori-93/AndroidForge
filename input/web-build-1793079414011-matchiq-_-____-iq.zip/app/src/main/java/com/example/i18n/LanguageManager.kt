package com.example.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

val LocalAppStrings = compositionLocalOf { EnglishStrings }

@Composable
fun MatchIQLocalization(
  language: AppLanguage,
  content: @Composable () -> Unit
) {
  val strings = if (language == AppLanguage.ARABIC) ArabicStrings else EnglishStrings
  val layoutDir = if (language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

  CompositionLocalProvider(
    LocalAppStrings provides strings,
    LocalLayoutDirection provides layoutDir
  ) {
    content()
  }
}
