package com.example.model

enum class PositionCategory {
  GOALKEEPER, DEFENDER, MIDFIELDER, FORWARD
}

enum class Position(val code: String, val category: PositionCategory) {
  GK("GK", PositionCategory.GOALKEEPER),
  CB("CB", PositionCategory.DEFENDER),
  LB("LB", PositionCategory.DEFENDER),
  RB("RB", PositionCategory.DEFENDER),
  LWB("LWB", PositionCategory.DEFENDER),
  RWB("RWB", PositionCategory.DEFENDER),
  DM("DM", PositionCategory.MIDFIELDER),
  CM("CM", PositionCategory.MIDFIELDER),
  AM("AM", PositionCategory.MIDFIELDER),
  LW("LW", PositionCategory.FORWARD),
  RW("RW", PositionCategory.FORWARD),
  CF("CF", PositionCategory.FORWARD),
  ST("ST", PositionCategory.FORWARD)
}

enum class PreferredFoot {
  RIGHT, LEFT, BOTH
}

enum class StatCategory {
  ATTACK,
  POSSESSION,
  DEFENSE,
  POSITION_TACTICAL,
  GOALKEEPER,
  HEADERS
}

enum class EventType(val category: StatCategory, val isNegative: Boolean = false, val isGoal: Boolean = false) {
  // Attack
  GOAL(StatCategory.ATTACK, isGoal = true),
  ASSIST(StatCategory.ATTACK),
  SHOT(StatCategory.ATTACK),
  SHOT_ON_TARGET(StatCategory.ATTACK),
  SHOT_OFF_TARGET(StatCategory.ATTACK, isNegative = true),
  BIG_CHANCE(StatCategory.ATTACK),
  KEY_PASS(StatCategory.ATTACK),
  SUCCESSFUL_DRIBBLE(StatCategory.ATTACK),
  FAILED_DRIBBLE(StatCategory.ATTACK, isNegative = true),
  CROSS_SUCCESSFUL(StatCategory.ATTACK),
  CROSS_FAILED(StatCategory.ATTACK, isNegative = true),
  THROUGH_BALL(StatCategory.ATTACK),
  PASS_INTO_BOX(StatCategory.ATTACK),
  PROGRESSIVE_RUN(StatCategory.ATTACK),
  PROGRESSIVE_PASS(StatCategory.ATTACK),

  // Possession
  PASS_COMPLETED(StatCategory.POSSESSION),
  PASS_FAILED(StatCategory.POSSESSION, isNegative = true),
  BALL_LOST(StatCategory.POSSESSION, isNegative = true),
  DISPOSSESSED(StatCategory.POSSESSION, isNegative = true),
  BAD_TOUCH(StatCategory.POSSESSION, isNegative = true),
  BALL_RECOVERY(StatCategory.POSSESSION),

  // Defending
  TACKLE_WON(StatCategory.DEFENSE),
  TACKLE_LOST(StatCategory.DEFENSE, isNegative = true),
  INTERCEPTION(StatCategory.DEFENSE),
  CLEARANCE(StatCategory.DEFENSE),
  BLOCK(StatCategory.DEFENSE),
  DEFENSIVE_DUEL_WON(StatCategory.DEFENSE),
  DEFENSIVE_DUEL_LOST(StatCategory.DEFENSE, isNegative = true),
  FOUL_COMMITTED(StatCategory.DEFENSE, isNegative = true),
  FOUL_WON(StatCategory.DEFENSE),
  YELLOW_CARD(StatCategory.DEFENSE, isNegative = true),
  RED_CARD(StatCategory.DEFENSE, isNegative = true),

  // Position / Tactical
  STAYED_IN_POSITION(StatCategory.POSITION_TACTICAL),
  LEFT_POSITION(StatCategory.POSITION_TACTICAL, isNegative = true),
  TOO_HIGH(StatCategory.POSITION_TACTICAL, isNegative = true),
  TOO_DEEP(StatCategory.POSITION_TACTICAL, isNegative = true),
  TOO_WIDE(StatCategory.POSITION_TACTICAL, isNegative = true),
  TOO_NARROW(StatCategory.POSITION_TACTICAL, isNegative = true),
  OUT_OF_POSITION(StatCategory.POSITION_TACTICAL, isNegative = true),
  MISSED_DEFENSIVE_ASSIGNMENT(StatCategory.POSITION_TACTICAL, isNegative = true),
  FAILED_TRACK_RUNNER(StatCategory.POSITION_TACTICAL, isNegative = true),
  GOOD_POSITIONING(StatCategory.POSITION_TACTICAL),
  SUCCESSFUL_PRESS(StatCategory.POSITION_TACTICAL),
  FAILED_PRESS(StatCategory.POSITION_TACTICAL, isNegative = true),
  COUNTER_ATTACK(StatCategory.POSITION_TACTICAL),
  COUNTER_ATTACK_FAILED(StatCategory.POSITION_TACTICAL, isNegative = true),
  HIGH_PRESS(StatCategory.POSITION_TACTICAL),
  LOW_BLOCK(StatCategory.POSITION_TACTICAL),

  // Goalkeeper
  GK_SAVE(StatCategory.GOALKEEPER),
  GK_EASY_SAVE(StatCategory.GOALKEEPER),
  GK_DANGEROUS_SAVE(StatCategory.GOALKEEPER),
  GK_1ON1_SAVE(StatCategory.GOALKEEPER),
  GK_CROSS_CLAIMED(StatCategory.GOALKEEPER),
  GK_HIGH_BALL_CLAIMED(StatCategory.GOALKEEPER),
  GK_SHOT_CONCEDED(StatCategory.GOALKEEPER, isNegative = true),
  GK_GOAL_CONCEDED(StatCategory.GOALKEEPER, isNegative = true),
  GK_PENALTY_FACED(StatCategory.GOALKEEPER),
  GK_PENALTY_SAVED(StatCategory.GOALKEEPER),
  GK_ERROR(StatCategory.GOALKEEPER, isNegative = true),
  GK_ERROR_LEAD_SHOT(StatCategory.GOALKEEPER, isNegative = true),
  GK_ERROR_LEAD_GOAL(StatCategory.GOALKEEPER, isNegative = true),
  GK_DISTRIBUTION_SUCCESS(StatCategory.GOALKEEPER),
  GK_DISTRIBUTION_FAILED(StatCategory.GOALKEEPER, isNegative = true),
  GK_SWEEPER_ACTION(StatCategory.GOALKEEPER),

  // Headers
  HEADER_WON(StatCategory.HEADERS),
  HEADER_LOST(StatCategory.HEADERS, isNegative = true),
  HEADER_SHOT(StatCategory.HEADERS),
  HEADER_GOAL(StatCategory.HEADERS, isGoal = true)
}

enum class PitchZone {
  DEF_LEFT, DEF_CENTER, DEF_RIGHT,
  MID_LEFT, MID_CENTER, MID_RIGHT,
  ATT_LEFT, ATT_CENTER, ATT_RIGHT
}

enum class GoalFinishType {
  RIGHT_FOOT, LEFT_FOOT, HEADER, PENALTY, FREE_KICK, LONG_RANGE, INSIDE_BOX, OUTSIDE_BOX
}

enum class AttackOrigin {
  LEFT_WING, RIGHT_WING, CENTRAL, COUNTER_ATTACK, SET_PIECE, CORNER
}

data class GoalMetadata(
  val assistPlayerId: Long? = null,
  val assistPlayerName: String? = null,
  val finishType: GoalFinishType = GoalFinishType.RIGHT_FOOT,
  val origin: AttackOrigin = AttackOrigin.CENTRAL
)

data class ActivityPeriodStats(
  val periodLabel: String,
  val startMinute: Int,
  val endMinute: Int,
  val totalActions: Int,
  val successfulActions: Int,
  val unsuccessfulActions: Int,
  val ballLosses: Int,
  val defensiveActions: Int,
  val offensiveActions: Int
)

data class PlayerMatchStats(
  val playerId: Long,
  val playerName: String,
  val shirtNumber: Int,
  val position: Position,
  val minutesPlayed: Int,
  val isStarting: Boolean,
  val goals: Int = 0,
  val assists: Int = 0,
  val shots: Int = 0,
  val shotsOnTarget: Int = 0,
  val shotsOffTarget: Int = 0,
  val passesCompleted: Int = 0,
  val passesFailed: Int = 0,
  val keyPasses: Int = 0,
  val dribblesSuccessful: Int = 0,
  val dribblesFailed: Int = 0,
  val ballLosses: Int = 0,
  val ballRecoveries: Int = 0,
  val tacklesWon: Int = 0,
  val tacklesLost: Int = 0,
  val interceptions: Int = 0,
  val clearances: Int = 0,
  val blocks: Int = 0,
  val foulsCommitted: Int = 0,
  val foulsWon: Int = 0,
  val yellowCards: Int = 0,
  val redCards: Int = 0,
  val outOfPosition: Int = 0,
  val stayedInPosition: Int = 0,
  val gkSaves: Int = 0,
  val gkDangerousSaves: Int = 0,
  val gkGoalsConceded: Int = 0,
  val gkCleanSheet: Boolean = false
) {
  val totalPasses: Int get() = passesCompleted + passesFailed
  val passAccuracyPercent: Float get() = if (totalPasses > 0) (passesCompleted.toFloat() / totalPasses * 100f) else 0f

  val totalDribbles: Int get() = dribblesSuccessful + dribblesFailed
  val dribbleSuccessPercent: Float get() = if (totalDribbles > 0) (dribblesSuccessful.toFloat() / totalDribbles * 100f) else 0f

  val totalShots: Int get() = shots + shotsOnTarget + shotsOffTarget
  val shotAccuracyPercent: Float get() = if (totalShots > 0) (shotsOnTarget.toFloat() / totalShots * 100f) else 0f

  val totalActions: Int get() = totalPasses + totalDribbles + totalShots + tacklesWon + tacklesLost + interceptions + clearances + ballRecoveries + gkSaves
}
