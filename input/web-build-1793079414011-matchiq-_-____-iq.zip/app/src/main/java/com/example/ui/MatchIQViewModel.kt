package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MatchIQRepository
import com.example.data.local.CoachPreferencesEntity
import com.example.data.local.MatchEntity
import com.example.data.local.MatchEventEntity
import com.example.data.local.MatchNoteEntity
import com.example.data.local.PlayerEntity
import com.example.data.local.SubstitutionEntity
import com.example.data.local.TeamEntity
import com.example.i18n.AppLanguage
import com.example.model.ActivityPeriodStats
import com.example.model.AttackOrigin
import com.example.model.EventType
import com.example.model.GoalFinishType
import com.example.model.GoalMetadata
import com.example.model.PitchZone
import com.example.model.PlayerMatchStats
import com.example.model.Position
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed class Screen {
  object MainTabs : Screen()
  data class LiveMatch(val matchId: Long) : Screen()
  data class MatchDetail(val matchId: Long) : Screen()
  data class PlayerProfile(val playerId: Long) : Screen()
  object CreateMatch : Screen()
  object CreateTeam : Screen()
}

enum class MainTab {
  DASHBOARD, MATCHES, TEAM, PLAYERS, REPORTS, SETTINGS
}

data class LiveFeedback(
  val message: String,
  val isPositive: Boolean = true,
  val timestamp: Long = System.currentTimeMillis()
)

class MatchIQViewModel(application: Application) : AndroidViewModel(application) {
  val repository = MatchIQRepository(application)
  private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
    val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
    vibratorManager?.defaultVibrator
  } else {
    @Suppress("DEPRECATION")
    application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
  }

  // Navigation
  private val _currentScreen = MutableStateFlow<Screen>(Screen.MainTabs)
  val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

  private val _currentTab = MutableStateFlow(MainTab.DASHBOARD)
  val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

  // App Settings / Preferences
  val preferences: StateFlow<CoachPreferencesEntity> = repository.getPreferences()
    .combine(MutableStateFlow(CoachPreferencesEntity())) { saved, default ->
      saved ?: default
    }.stateIn(viewModelScope, SharingStarted.Eagerly, CoachPreferencesEntity())

  // Teams & Players
  val allTeams: StateFlow<List<TeamEntity>> = repository.getAllTeams()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allMatches: StateFlow<List<MatchEntity>> = repository.getAllMatches()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val liveMatch: StateFlow<MatchEntity?> = repository.getLiveMatch()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val latestFinishedMatch: StateFlow<MatchEntity?> = repository.getLatestFinishedMatch()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  // Live Match Session State
  private val _activeLiveMatch = MutableStateFlow<MatchEntity?>(null)
  val activeLiveMatch: StateFlow<MatchEntity?> = _activeLiveMatch.asStateFlow()

  private val _matchSquad = MutableStateFlow<List<PlayerEntity>>(emptyList())
  val matchSquad: StateFlow<List<PlayerEntity>> = _matchSquad.asStateFlow()

  private val _selectedPlayer = MutableStateFlow<PlayerEntity?>(null)
  val selectedPlayer: StateFlow<PlayerEntity?> = _selectedPlayer.asStateFlow()

  private val _liveEvents = MutableStateFlow<List<MatchEventEntity>>(emptyList())
  val liveEvents: StateFlow<List<MatchEventEntity>> = _liveEvents.asStateFlow()

  private val _liveFeedback = MutableStateFlow<LiveFeedback?>(null)
  val liveFeedback: StateFlow<LiveFeedback?> = _liveFeedback.asStateFlow()

  private val _selectedPitchZone = MutableStateFlow<PitchZone?>(null)
  val selectedPitchZone: StateFlow<PitchZone?> = _selectedPitchZone.asStateFlow()

  // Timer Coroutine
  private var clockJob: Job? = null

  // Modals & Sheets
  private val _showGoalDialog = MutableStateFlow(false)
  val showGoalDialog: StateFlow<Boolean> = _showGoalDialog.asStateFlow()

  private val _showSubDialog = MutableStateFlow(false)
  val showSubDialog: StateFlow<Boolean> = _showSubDialog.asStateFlow()

  private val _showEventHistoryDialog = MutableStateFlow(false)
  val showEventHistoryDialog: StateFlow<Boolean> = _showEventHistoryDialog.asStateFlow()

  private val _showNotesDialog = MutableStateFlow(false)
  val showNotesDialog: StateFlow<Boolean> = _showNotesDialog.asStateFlow()

  private val _showExitConfirmDialog = MutableStateFlow(false)
  val showExitConfirmDialog: StateFlow<Boolean> = _showExitConfirmDialog.asStateFlow()

  private val _showEndMatchConfirmDialog = MutableStateFlow(false)
  val showEndMatchConfirmDialog: StateFlow<Boolean> = _showEndMatchConfirmDialog.asStateFlow()

  private val _showMoreStats = MutableStateFlow(false)
  val showMoreStats: StateFlow<Boolean> = _showMoreStats.asStateFlow()

  private val _showAllSquadGrid = MutableStateFlow(false)
  val showAllSquadGrid: StateFlow<Boolean> = _showAllSquadGrid.asStateFlow()

  // Navigation functions
  fun setTab(tab: MainTab) {
    _currentTab.value = tab
    _currentScreen.value = Screen.MainTabs
  }

  fun navigateTo(screen: Screen) {
    if (screen is Screen.LiveMatch) {
      loadLiveMatchSession(screen.matchId)
    }
    _currentScreen.value = screen
  }

  fun goBack() {
    when (val screen = _currentScreen.value) {
      is Screen.LiveMatch -> {
        // Intercept back button during live match
        _showExitConfirmDialog.value = true
      }
      is Screen.MatchDetail, is Screen.PlayerProfile, is Screen.CreateMatch, is Screen.CreateTeam -> {
        _currentScreen.value = Screen.MainTabs
      }
      Screen.MainTabs -> {
        // Already at root tabs
      }
    }
  }

  // Preferences Actions
  fun setLanguage(lang: AppLanguage) {
    viewModelScope.launch {
      repository.updateLanguage(lang)
    }
  }

  fun toggleDarkMode(isDark: Boolean) {
    viewModelScope.launch {
      repository.updateDarkMode(isDark)
    }
  }

  fun toggleHaptic(enabled: Boolean) {
    viewModelScope.launch {
      repository.updateHaptic(enabled)
    }
  }

  fun resetToDemoData() {
    viewModelScope.launch {
      repository.clearAllData()
    }
  }

  // Live Match Loading & Operations
  fun loadLiveMatchSession(matchId: Long) {
    viewModelScope.launch {
      val match = repository.getMatchById(matchId) ?: return@launch
      _activeLiveMatch.value = match
      val players = repository.getPlayersForTeamList(match.teamId)
      _matchSquad.value = players
      if (_selectedPlayer.value == null || !players.contains(_selectedPlayer.value)) {
        _selectedPlayer.value = players.firstOrNull { it.isStarter } ?: players.firstOrNull()
      }
      startClock(match)

      // Collect events in real time
      repository.getEventsForMatch(matchId).collect { evs ->
        _liveEvents.value = evs
      }
    }
  }

  fun selectPlayer(player: PlayerEntity) {
    _selectedPlayer.value = player
    _showAllSquadGrid.value = false
    triggerHaptic()
  }

  fun selectPitchZone(zone: PitchZone?) {
    _selectedPitchZone.value = if (_selectedPitchZone.value == zone) null else zone
    triggerHaptic()
  }

  fun toggleMoreStats() {
    _showMoreStats.value = !_showMoreStats.value
  }

  fun toggleAllSquadGrid() {
    _showAllSquadGrid.value = !_showAllSquadGrid.value
  }

  // Clock Control
  private fun startClock(match: MatchEntity) {
    clockJob?.cancel()
    clockJob = viewModelScope.launch {
      while (isActive) {
        delay(1000)
        val current = _activeLiveMatch.value ?: break
        if (current.isLive && !current.isPaused) {
          var sec = current.currentSecond + 1
          var min = current.currentMinute
          var half = current.currentHalf
          if (sec >= 60) {
            sec = 0
            min += 1
            if (min >= 45 && half == 1) {
              // Halftime mark
            }
          }
          val updated = current.copy(currentMinute = min, currentSecond = sec, currentHalf = half)
          _activeLiveMatch.value = updated
          repository.updateMatch(updated)
        }
      }
    }
  }

  fun pauseResumeClock() {
    val current = _activeLiveMatch.value ?: return
    val updated = current.copy(isPaused = !current.isPaused)
    _activeLiveMatch.value = updated
    viewModelScope.launch {
      repository.updateMatch(updated)
    }
    triggerHaptic()
  }

  // Record Event
  fun recordEvent(eventType: EventType, customNote: String = "", goalMeta: GoalMetadata? = null) {
    val match = _activeLiveMatch.value ?: return
    val player = _selectedPlayer.value ?: return
    val zone = _selectedPitchZone.value

    viewModelScope.launch {
      repository.recordEvent(
        matchId = match.id,
        player = player,
        eventType = eventType,
        minute = match.currentMinute,
        second = match.currentSecond,
        half = match.currentHalf,
        zone = zone,
        notes = customNote,
        goalMetadata = goalMeta
      )

      // Refresh score
      if (eventType.isGoal) {
        val updatedMatch = repository.getMatchById(match.id)
        if (updatedMatch != null) _activeLiveMatch.value = updatedMatch
      }

      // Visual pill feedback
      val langIsAr = preferences.value.language == "ar"
      val label = if (langIsAr) {
        when (eventType) {
          EventType.PASS_COMPLETED -> "✓ تمريرة ناجحة +1"
          EventType.PASS_FAILED -> "تمريرة خاطئة +1"
          EventType.SHOT -> "تسديدة +1"
          EventType.SHOT_ON_TARGET -> "🎯 تسديدة على المرمى +1"
          EventType.GOAL -> "⚽ هدف ممتاز!"
          EventType.SUCCESSFUL_DRIBBLE -> "مراوغة ناجحة +1"
          EventType.BALL_LOST -> "فقدان الكرة +1"
          EventType.BALL_RECOVERY -> "استرجاع الكرة +1"
          EventType.TACKLE_WON -> "افتكاك ناجح +1"
          EventType.INTERCEPTION -> "اعتراض +1"
          EventType.GK_SAVE -> "🧤 تصدٍ رائع +1"
          else -> "${eventType.name} +1"
        }
      } else {
        when (eventType) {
          EventType.PASS_COMPLETED -> "✓ Pass Completed +1"
          EventType.PASS_FAILED -> "Pass Failed +1"
          EventType.SHOT -> "Shot +1"
          EventType.SHOT_ON_TARGET -> "🎯 Shot On Target +1"
          EventType.GOAL -> "⚽ GOAL!"
          EventType.SUCCESSFUL_DRIBBLE -> "Dribble Success +1"
          EventType.BALL_LOST -> "Ball Lost +1"
          EventType.BALL_RECOVERY -> "Ball Recovery +1"
          EventType.TACKLE_WON -> "Tackle Won +1"
          EventType.INTERCEPTION -> "Interception +1"
          EventType.GK_SAVE -> "🧤 GK Save +1"
          else -> "${eventType.name} +1"
        }
      }
      _liveFeedback.value = LiveFeedback(label, isPositive = !eventType.isNegative)
      triggerHaptic()
    }
  }

  fun recordOpponentGoal() {
    val match = _activeLiveMatch.value ?: return
    viewModelScope.launch {
      repository.recordOpponentGoal(match.id, match.currentMinute, match.currentSecond, match.currentHalf)
      val updated = repository.getMatchById(match.id)
      if (updated != null) _activeLiveMatch.value = updated
      _liveFeedback.value = LiveFeedback("Opponent Goal +1", isPositive = false)
      triggerHaptic()
    }
  }

  fun undoLastEvent() {
    val match = _activeLiveMatch.value ?: return
    viewModelScope.launch {
      val undone = repository.undoLastEvent(match.id)
      if (undone != null) {
        val updated = repository.getMatchById(match.id)
        if (updated != null) _activeLiveMatch.value = updated
        val isAr = preferences.value.language == "ar"
        _liveFeedback.value = LiveFeedback(
          if (isAr) "تم التراجع عن: ${undone.playerName} (${undone.eventType})" else "Undone: ${undone.playerName} (${undone.eventType})",
          isPositive = false
        )
      }
      triggerHaptic()
    }
  }

  fun deleteEvent(eventId: Long) {
    val match = _activeLiveMatch.value ?: return
    viewModelScope.launch {
      repository.deleteEvent(match.id, eventId)
      val updated = repository.getMatchById(match.id)
      if (updated != null) _activeLiveMatch.value = updated
    }
  }

  fun executeSubstitution(playerOut: PlayerEntity, playerIn: PlayerEntity) {
    val match = _activeLiveMatch.value ?: return
    viewModelScope.launch {
      repository.recordSubstitution(match.id, match.currentMinute, playerOut, playerIn)
      _selectedPlayer.value = playerIn
      _showSubDialog.value = false
      val isAr = preferences.value.language == "ar"
      _liveFeedback.value = LiveFeedback(
        if (isAr) "🔄 تبديل: خروج ${playerOut.name} ⬅ دخول ${playerIn.name}" else "🔄 Sub: ${playerOut.name} ⬅ ${playerIn.name}"
      )
      triggerHaptic()
    }
  }

  fun recordGoalDetails(scorer: PlayerEntity, assist: PlayerEntity?, finishType: GoalFinishType, origin: AttackOrigin) {
    val meta = GoalMetadata(
      assistPlayerId = assist?.id,
      assistPlayerName = assist?.name,
      finishType = finishType,
      origin = origin
    )
    _selectedPlayer.value = scorer
    recordEvent(EventType.GOAL, goalMeta = meta)
    _showGoalDialog.value = false
  }

  fun addNote(text: String) {
    val match = _activeLiveMatch.value ?: return
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.addMatchNote(match.id, match.currentMinute, text.trim())
      _showNotesDialog.value = false
      _liveFeedback.value = LiveFeedback("Note recorded")
    }
  }

  fun finishMatch() {
    val match = _activeLiveMatch.value ?: return
    clockJob?.cancel()
    viewModelScope.launch {
      val finished = match.copy(isLive = false, isFinished = true, isPaused = true)
      repository.updateMatch(finished)
      _activeLiveMatch.value = finished
      _showEndMatchConfirmDialog.value = false
      _currentScreen.value = Screen.MatchDetail(match.id)
    }
  }

  fun confirmExitLiveMatch(saveAndReturnToDashboard: Boolean) {
    _showExitConfirmDialog.value = false
    if (saveAndReturnToDashboard) {
      _currentScreen.value = Screen.MainTabs
      _currentTab.value = MainTab.DASHBOARD
    }
  }

  fun discardMatch() {
    val match = _activeLiveMatch.value ?: return
    clockJob?.cancel()
    viewModelScope.launch {
      repository.deleteMatch(match.id)
      _activeLiveMatch.value = null
      _showExitConfirmDialog.value = false
      _currentScreen.value = Screen.MainTabs
    }
  }

  // Dialog Show/Hide
  fun showGoalDialog(show: Boolean) { _showGoalDialog.value = show }
  fun showSubDialog(show: Boolean) { _showSubDialog.value = show }
  fun showEventHistoryDialog(show: Boolean) { _showEventHistoryDialog.value = show }
  fun showNotesDialog(show: Boolean) { _showNotesDialog.value = show }
  fun showExitConfirmDialog(show: Boolean) { _showExitConfirmDialog.value = show }
  fun showEndMatchConfirmDialog(show: Boolean) { _showEndMatchConfirmDialog.value = show }

  // Quick Stats Config
  fun getQuickStatsList(): List<EventType> {
    val json = preferences.value.quickStatsJson
    if (json.isBlank()) return MatchIQRepository.DEFAULT_QUICK_STATS
    return try {
      json.split(",").mapNotNull { name ->
        try { EventType.valueOf(name.trim()) } catch (_: Exception) { null }
      }.ifEmpty { MatchIQRepository.DEFAULT_QUICK_STATS }
    } catch (_: Exception) {
      MatchIQRepository.DEFAULT_QUICK_STATS
    }
  }

  private fun triggerHaptic() {
    if (!preferences.value.hapticFeedback) return
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(35)
      }
    } catch (_: Exception) {}
  }
}
