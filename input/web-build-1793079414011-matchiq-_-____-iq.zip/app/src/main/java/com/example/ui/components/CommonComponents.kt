package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PitchZone
import com.example.model.Position
import com.example.model.PositionCategory
import com.example.ui.LiveFeedback
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.StatDangerRed
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.delay

@Composable
fun LargeStatButton(
  label: String,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  accentColor: Color = PitchGreenLight,
  containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
  counter: Int? = null,
  testTag: String = ""
) {
  Card(
    modifier = modifier
      .height(68.dp)
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(accentColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(22.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = label,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          fontSize = 13.sp
        )
      }

      if (counter != null && counter > 0) {
        Box(
          modifier = Modifier
            .padding(start = 6.dp)
            .clip(CircleShape)
            .background(accentColor)
            .padding(horizontal = 8.dp, vertical = 3.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "$counter",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
            color = Color.Black
          )
        }
      } else {
        Text(
          text = "+1",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
          color = accentColor.copy(alpha = 0.85f),
          modifier = Modifier.padding(start = 4.dp)
        )
      }
    }
  }
}

@Composable
fun PlayerAvatarBadge(
  shirtNumber: Int,
  name: String,
  position: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  eventCount: Int? = null,
  isGoalkeeper: Boolean = false
) {
  val borderColor = if (isSelected) PitchGreenLight else Color.Transparent
  val bgColor = if (isSelected) PitchGreenPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant

  Card(
    modifier = modifier
      .width(82.dp)
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .border(2.dp, borderColor, RoundedCornerShape(12.dp))
      .testTag("player_badge_$shirtNumber"),
    colors = CardDefaults.cardColors(containerColor = bgColor)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp, horizontal = 4.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(if (isGoalkeeper) TacticalCyan.copy(alpha = 0.25f) else PitchGreenDark),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "#$shirtNumber",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
          color = Color.White,
          fontSize = 14.sp
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = name.substringBefore(" ").ifEmpty { name },
        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        fontSize = 11.sp
      )
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Text(
          text = position,
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = if (isGoalkeeper) TacticalCyan else PitchGreenLight,
          fontSize = 10.sp
        )
        if (eventCount != null && eventCount > 0) {
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = "• $eventCount",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 9.sp
          )
        }
      }
    }
  }
}

@Composable
fun PitchZoneSelector(
  selectedZone: PitchZone?,
  onZoneSelected: (PitchZone?) -> Unit,
  modifier: Modifier = Modifier
) {
  val zones = listOf(
    listOf(PitchZone.DEF_LEFT, PitchZone.DEF_CENTER, PitchZone.DEF_RIGHT),
    listOf(PitchZone.MID_LEFT, PitchZone.MID_CENTER, PitchZone.MID_RIGHT),
    listOf(PitchZone.ATT_LEFT, PitchZone.ATT_CENTER, PitchZone.ATT_RIGHT)
  )
  val zoneNames = mapOf(
    PitchZone.DEF_LEFT to "DL", PitchZone.DEF_CENTER to "DC", PitchZone.DEF_RIGHT to "DR",
    PitchZone.MID_LEFT to "ML", PitchZone.MID_CENTER to "MC", PitchZone.MID_RIGHT to "MR",
    PitchZone.ATT_LEFT to "AL", PitchZone.ATT_CENTER to "AC", PitchZone.ATT_RIGHT to "AR"
  )

  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFF0F2318))
      .border(1.dp, PitchGreenLight.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
      .padding(4.dp)
  ) {
    zones.forEach { row ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        row.forEach { zone ->
          val isSelected = selectedZone == zone
          Box(
            modifier = Modifier
              .weight(1f)
              .height(28.dp)
              .clip(RoundedCornerShape(4.dp))
              .background(if (isSelected) PitchGreenLight else Color(0x3310B981))
              .clickable { onZoneSelected(if (isSelected) null else zone) },
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = zoneNames[zone] ?: "",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = if (isSelected) Color.Black else Color.White,
              fontSize = 10.sp
            )
          }
        }
      }
      if (row != zones.last()) {
        Spacer(modifier = Modifier.height(4.dp))
      }
    }
  }
}

@Composable
fun FloatingFeedbackToast(
  feedback: LiveFeedback?,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  LaunchedEffect(feedback) {
    if (feedback != null) {
      delay(1400)
      onDismiss()
    }
  }

  AnimatedVisibility(
    visible = feedback != null,
    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
    modifier = modifier
  ) {
    feedback?.let { fb ->
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = if (fb.isPositive) Color(0xFF064E3B) else Color(0xFF7F1D1D),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (fb.isPositive) PitchGreenLight else StatDangerRed
        ),
        shadowElevation = 6.dp,
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (fb.isPositive) Icons.Default.Check else Icons.Default.Close,
            contentDescription = null,
            tint = if (fb.isPositive) PitchGreenLight else Color.White,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = fb.message,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }
      }
    }
  }
}
