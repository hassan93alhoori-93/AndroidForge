package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.LocalAppStrings
import com.example.data.local.PlayerEntity
import com.example.model.Position
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch

@Composable
fun CreateMatchScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val teams by viewModel.allTeams.collectAsState()
  val team = teams.firstOrNull()
  val coroutineScope = rememberCoroutineScope()

  BackHandler {
    viewModel.goBack()
  }

  var opponent by remember { mutableStateOf("Al-Hilal Academy") }
  var competition by remember { mutableStateOf("League Match - Week 5") }
  var venue by remember { mutableStateOf("Main Pitch") }
  var duration by remember { mutableIntStateOf(90) }
  var isHome by remember { mutableStateOf(true) }
  var selectedFormation by remember { mutableStateOf(team?.defaultFormation ?: "4-3-3") }

  // Squad selection
  var squad by remember { mutableStateOf<List<PlayerEntity>>(emptyList()) }
  val selectedStarters = remember { mutableStateListOf<Long>() }

  androidx.compose.runtime.LaunchedEffect(team) {
    if (team != null) {
      val players = viewModel.repository.getPlayersForTeamList(team.id)
      squad = players
      selectedStarters.clear()
      // Default to starters
      players.filter { it.isStarter }.take(11).forEach {
        selectedStarters.add(it.id)
      }
      if (selectedStarters.size < 11) {
        players.take(11).forEach {
          if (!selectedStarters.contains(it.id)) selectedStarters.add(it.id)
        }
      }
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(onClick = { viewModel.goBack() }) {
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
      }
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = s.createMatch,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        OutlinedTextField(
          value = opponent,
          onValueChange = { opponent = it },
          label = { Text(s.opponentName) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("match_opponent_input")
        )
      }

      item {
        OutlinedTextField(
          value = competition,
          onValueChange = { competition = it },
          label = { Text(s.competition) },
          modifier = Modifier.fillMaxWidth()
        )
      }

      item {
        OutlinedTextField(
          value = venue,
          onValueChange = { venue = it },
          label = { Text(s.venue) },
          modifier = Modifier.fillMaxWidth()
        )
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(text = if (isHome) s.homeMatch else s.awayMatch, fontWeight = FontWeight.Bold)
          Switch(
            checked = isHome,
            onCheckedChange = { isHome = it },
            colors = SwitchDefaults.colors(checkedThumbColor = PitchGreenLight, checkedTrackColor = PitchGreenDark)
          )
        }
      }

      // Duration selector
      item {
        Text(text = s.matchDuration, style = MaterialTheme.typography.labelMedium, color = PitchGreenLight)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
          listOf(45, 60, 70, 80, 90).forEach { mins ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (duration == mins) PitchGreenDark else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.clickable { duration = mins }
            ) {
              Text(
                text = "$mins'",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
              )
            }
          }
        }
      }

      // Formation selector
      item {
        Text(text = s.formation, style = MaterialTheme.typography.labelMedium, color = TacticalCyan)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
          listOf("4-3-3", "4-2-3-1", "4-4-2", "3-5-2", "3-4-3").forEach { form ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (selectedFormation == form) TacticalCyan else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.clickable { selectedFormation = form }
            ) {
              Text(
                text = form,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
              )
            }
          }
        }
      }

      // Starting XI selection list
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${s.startingXI} (${selectedStarters.size} / 11)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = if (selectedStarters.size == 11) PitchGreenLight else Color.LightGray
          )
        }
      }

      items(squad) { player ->
        val isSelected = selectedStarters.contains(player.id)
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF0F2B1D) else MaterialTheme.colorScheme.surfaceVariant
          ),
          border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, PitchGreenLight) else null,
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              if (isSelected) {
                selectedStarters.remove(player.id)
              } else {
                if (selectedStarters.size < 11) {
                  selectedStarters.add(player.id)
                }
              }
            }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(if (isSelected) PitchGreenLight else Color.Gray),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "#${player.shirtNumber}",
                  fontWeight = FontWeight.Black,
                  fontSize = 12.sp,
                  color = Color.Black
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = player.name, fontWeight = FontWeight.Bold, color = Color.White)
                Text(text = "${player.position} • ${player.preferredFoot}", fontSize = 11.sp, color = Color.Gray)
              }
            }

            Checkbox(
              checked = isSelected,
              onCheckedChange = {
                if (it) {
                  if (selectedStarters.size < 11) selectedStarters.add(player.id)
                } else {
                  selectedStarters.remove(player.id)
                }
              },
              colors = CheckboxDefaults.colors(checkedColor = PitchGreenLight)
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(30.dp)) }
    }

    // [START MATCH] Button
    Button(
      onClick = {
        if (team != null && opponent.isNotBlank()) {
          coroutineScope.launch {
            // Update starters in DB
            squad.forEach { p ->
              viewModel.repository.savePlayer(p.copy(isStarter = selectedStarters.contains(p.id)))
            }
            val matchId = viewModel.repository.startMatch(
              teamId = team.id,
              opponentName = opponent.trim(),
              competition = competition.trim(),
              venue = venue.trim(),
              isHome = isHome,
              duration = duration
            )
            viewModel.navigateTo(Screen.LiveMatch(matchId))
          }
        }
      },
      colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(54.dp)
        .testTag("start_match_submit_button")
    ) {
      Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = s.startMatch,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
        color = Color.White
      )
    }
    Spacer(modifier = Modifier.height(14.dp))
  }
}
