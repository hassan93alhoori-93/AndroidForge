package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.LocalAppStrings
import com.example.model.AttackOrigin
import com.example.model.EventType
import com.example.model.GoalFinishType
import com.example.model.PitchZone
import com.example.data.local.PlayerEntity
import com.example.model.Position
import com.example.model.StatCategory
import com.example.ui.MatchIQViewModel
import com.example.ui.components.FloatingFeedbackToast
import com.example.ui.components.LargeStatButton
import com.example.ui.components.PitchZoneSelector
import com.example.ui.components.PlayerAvatarBadge
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.StatDangerRed
import com.example.ui.theme.StatWarningYellow
import com.example.ui.theme.TacticalCyan
import com.example.ui.theme.TacticalCyanLight

@Composable
fun LiveMatchScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val match by viewModel.activeLiveMatch.collectAsState()
  val squad by viewModel.matchSquad.collectAsState()
  val selectedPlayer by viewModel.selectedPlayer.collectAsState()
  val events by viewModel.liveEvents.collectAsState()
  val liveFeedback by viewModel.liveFeedback.collectAsState()
  val selectedZone by viewModel.selectedPitchZone.collectAsState()

  val showGoalDialog by viewModel.showGoalDialog.collectAsState()
  val showSubDialog by viewModel.showSubDialog.collectAsState()
  val showHistoryDialog by viewModel.showEventHistoryDialog.collectAsState()
  val showNotesDialog by viewModel.showNotesDialog.collectAsState()
  val showExitConfirm by viewModel.showExitConfirmDialog.collectAsState()
  val showEndConfirm by viewModel.showEndMatchConfirmDialog.collectAsState()
  val showMoreStats by viewModel.showMoreStats.collectAsState()
  val showAllSquadGrid by viewModel.showAllSquadGrid.collectAsState()

  // Prevent accidental back navigation
  BackHandler {
    viewModel.showExitConfirmDialog(true)
  }

  if (match == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("Loading live session...", color = Color.White)
    }
    return
  }

  val activeMatch = match!!
  val isGk = selectedPlayer?.position == Position.GK.name

  // Player's recorded events in current match
  val playerEvents = events.filter { it.playerId == selectedPlayer?.id }
  val playerGoals = playerEvents.count { it.eventType == EventType.GOAL.name || it.eventType == EventType.HEADER_GOAL.name }
  val playerShots = playerEvents.count { it.eventType == EventType.SHOT.name || it.eventType == EventType.SHOT_ON_TARGET.name }
  val playerPasses = playerEvents.count { it.eventType == EventType.PASS_COMPLETED.name }
  val playerTackles = playerEvents.count { it.eventType == EventType.TACKLE_WON.name }
  val playerSaves = playerEvents.count { it.eventType.contains("SAVE") }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(top = 8.dp)
    ) {

      // ─── 1. TOP BAR: MATCH CLOCK & SCOREBOARD ───
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          // Clock row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (activeMatch.isPaused) StatWarningYellow else PitchGreenLight)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${if (activeMatch.currentHalf == 1) s.firstHalf else s.secondHalf} • ${String.format("%02d:%02d", activeMatch.currentMinute, activeMatch.currentSecond)}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                color = Color.White
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              IconButton(
                onClick = { viewModel.pauseResumeClock() },
                modifier = Modifier
                  .size(36.dp)
                  .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                  .testTag("clock_pause_resume_button")
              ) {
                Icon(
                  imageVector = if (activeMatch.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                  contentDescription = null,
                  tint = if (activeMatch.isPaused) PitchGreenLight else StatWarningYellow,
                  modifier = Modifier.size(20.dp)
                )
              }

              Button(
                onClick = { viewModel.showEndMatchConfirmDialog(true) },
                colors = ButtonDefaults.buttonColors(containerColor = StatDangerRed),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                  .height(36.dp)
                  .testTag("end_match_button")
              ) {
                Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(s.endMatch, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Scoreboard row
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Text(
                text = s.ourTeam,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = PitchGreenLight
              )
              Spacer(modifier = Modifier.width(8.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = PitchGreenDark,
                modifier = Modifier.padding(vertical = 2.dp)
              ) {
                Text(
                  text = "${activeMatch.ourScore}",
                  style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
              }
            }

            Text(
              text = "—",
              style = MaterialTheme.typography.titleMedium,
              color = Color.Gray,
              modifier = Modifier.padding(horizontal = 8.dp)
            )

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.End,
              modifier = Modifier.weight(1f)
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF334155),
                modifier = Modifier.padding(vertical = 2.dp)
              ) {
                Text(
                  text = "${activeMatch.opponentScore}",
                  style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = activeMatch.opponentName.take(12),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.LightGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // ─── 2. HORIZONTAL SQUAD STRIP + ALL SQUAD BUTTON ───
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        LazyRow(
          modifier = Modifier.weight(1f),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(squad) { player ->
            val pEventsCount = events.count { it.playerId == player.id }
            PlayerAvatarBadge(
              shirtNumber = player.shirtNumber,
              name = player.name,
              position = player.position,
              isSelected = player.id == selectedPlayer?.id,
              onClick = { viewModel.selectPlayer(player) },
              eventCount = pEventsCount,
              isGoalkeeper = player.position == Position.GK.name
            )
          }
        }

        Spacer(modifier = Modifier.width(6.dp))
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (showAllSquadGrid) PitchGreenLight else Color(0xFF1E293B),
          modifier = Modifier
            .clickable { viewModel.toggleAllSquadGrid() }
            .testTag("all_squad_grid_toggle")
        ) {
          Text(
            text = s.allPlayers,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (showAllSquadGrid) Color.Black else Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 14.dp),
            textAlign = TextAlign.Center
          )
        }
      }

      // If Coach clicked [ALL SQUAD], show full squad selection grid
      if (showAllSquadGrid) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF131C2A)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = s.selectPlayer,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = PitchGreenLight
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyVerticalGrid(
              columns = GridCells.Fixed(4),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.height(160.dp)
            ) {
              items(squad) { p ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedPlayer?.id == p.id) PitchGreenDark else Color(0xFF1E293B),
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { viewModel.selectPlayer(p) }
                    .padding(4.dp)
                ) {
                  Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(4.dp)
                  ) {
                    Text("#${p.shirtNumber} ${p.position}", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text(p.name.substringBefore(" "), fontSize = 10.sp, color = Color.LightGray, maxLines = 1)
                  }
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // ─── 3. ACTIVE SELECTED PLAYER HEADER CARD ───
      selectedPlayer?.let { p ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF15202E)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26354A)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(if (isGk) TacticalCyan else PitchGreenPrimary),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "#${p.shirtNumber}",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                  color = Color.Black
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = p.name,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color.White,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = "${s.position}: ${p.position} • ${activeMatch.currentMinute} ${s.playingTimeMin}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            // Quick live stats badges for this player
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              if (isGk) {
                StatBadge(label = "🧤 $playerSaves")
              } else {
                StatBadge(label = "⚽ $playerGoals")
                StatBadge(label = "🎯 $playerShots")
                StatBadge(label = "✓ $playerPasses")
                StatBadge(label = "🛡 $playerTackles")
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // ─── 4. STATISTIC EVENT BUTTONS (SCROLLABLE SIDELINE PANEL) ───
      LazyColumn(
        modifier = Modifier
          .weight(1f)
          .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {

        // Optional Pitch Zone Selector Header
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (selectedZone != null) "${s.optionalPitchZone}: ${selectedZone?.name}" else s.optionalPitchZone,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = if (selectedZone != null) PitchGreenLight else Color.Gray
            )
            if (selectedZone != null) {
              Text(
                text = "Clear Zone",
                style = MaterialTheme.typography.labelSmall,
                color = StatDangerRed,
                modifier = Modifier.clickable { viewModel.selectPitchZone(null) }
              )
            }
          }
          PitchZoneSelector(
            selectedZone = selectedZone,
            onZoneSelected = { viewModel.selectPitchZone(it) },
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
          )
        }

        // GOALKEEPER MODE (If player is GK, show specialized GK stats prominently!)
        if (isGk) {
          item {
            Text(
              text = "🧤 ${s.catGoalkeeper}",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
              color = TacticalCyanLight
            )
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statGkSave,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.GK_SAVE) },
                accentColor = TacticalCyanLight,
                modifier = Modifier.weight(1f),
                testTag = "gk_save_button"
              )
              LargeStatButton(
                label = s.statGkDangerousSave,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.GK_DANGEROUS_SAVE) },
                accentColor = TacticalCyan,
                modifier = Modifier.weight(1f),
                testTag = "gk_dangerous_save_button"
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statGk1on1Save,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.GK_1ON1_SAVE) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statGkCrossClaimed,
                icon = Icons.Default.SportsSoccer,
                onClick = { viewModel.recordEvent(EventType.GK_CROSS_CLAIMED) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statGkDistributionSuccess,
                icon = Icons.Default.SportsSoccer,
                onClick = { viewModel.recordEvent(EventType.GK_DISTRIBUTION_SUCCESS) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statGkDistributionFailed,
                icon = Icons.Default.Close,
                onClick = { viewModel.recordEvent(EventType.GK_DISTRIBUTION_FAILED) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statGkPenaltySaved,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.GK_PENALTY_SAVED) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statGkGoalConceded,
                icon = Icons.Default.SportsSoccer,
                onClick = { viewModel.recordEvent(EventType.GK_GOAL_CONCEDED) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }
        }

        // QUICK STATS SECTION (1-Tap Mode)
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isGk) "GENERAL ACTIONS" else "⚡ ${s.quickMode}",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
              color = PitchGreenLight
            )
            Text(
              text = if (showMoreStats) "${s.moreStats} ▲" else "${s.moreStats} ▼",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = TacticalCyan,
              modifier = Modifier.clickable { viewModel.toggleMoreStats() }
            )
          }
        }

        // Quick Mode primary grid (Pairs of large buttons)
        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeStatButton(
              label = s.statPassCompleted,
              icon = Icons.Default.SportsSoccer,
              onClick = { viewModel.recordEvent(EventType.PASS_COMPLETED) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.PASS_COMPLETED.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_pass_completed"
            )
            LargeStatButton(
              label = s.statPassFailed,
              icon = Icons.Default.Close,
              onClick = { viewModel.recordEvent(EventType.PASS_FAILED) },
              accentColor = StatDangerRed,
              counter = playerEvents.count { it.eventType == EventType.PASS_FAILED.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_pass_failed"
            )
          }
        }

        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeStatButton(
              label = s.statShotOnTarget,
              icon = Icons.Default.SportsSoccer,
              onClick = { viewModel.recordEvent(EventType.SHOT_ON_TARGET) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.SHOT_ON_TARGET.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_shot_on_target"
            )
            LargeStatButton(
              label = s.statShotOffTarget,
              icon = Icons.Default.SportsSoccer,
              onClick = { viewModel.recordEvent(EventType.SHOT_OFF_TARGET) },
              accentColor = StatDangerRed,
              counter = playerEvents.count { it.eventType == EventType.SHOT_OFF_TARGET.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_shot_off_target"
            )
          }
        }

        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeStatButton(
              label = s.statDribbleSuccess,
              icon = Icons.Default.PlayArrow,
              onClick = { viewModel.recordEvent(EventType.SUCCESSFUL_DRIBBLE) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.SUCCESSFUL_DRIBBLE.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_dribble_success"
            )
            LargeStatButton(
              label = s.statBallLost,
              icon = Icons.Default.Close,
              onClick = { viewModel.recordEvent(EventType.BALL_LOST) },
              accentColor = StatDangerRed,
              counter = playerEvents.count { it.eventType == EventType.BALL_LOST.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_ball_lost"
            )
          }
        }

        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeStatButton(
              label = s.statKeyPass,
              icon = Icons.Default.PlayArrow,
              onClick = { viewModel.recordEvent(EventType.KEY_PASS) },
              accentColor = TacticalCyan,
              counter = playerEvents.count { it.eventType == EventType.KEY_PASS.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_key_pass"
            )
            LargeStatButton(
              label = s.statTackleWon,
              icon = Icons.Default.Shield,
              onClick = { viewModel.recordEvent(EventType.TACKLE_WON) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.TACKLE_WON.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_tackle_won"
            )
          }
        }

        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LargeStatButton(
              label = s.statInterception,
              icon = Icons.Default.Shield,
              onClick = { viewModel.recordEvent(EventType.INTERCEPTION) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.INTERCEPTION.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_interception"
            )
            LargeStatButton(
              label = s.statBallRecovery,
              icon = Icons.Default.SportsSoccer,
              onClick = { viewModel.recordEvent(EventType.BALL_RECOVERY) },
              accentColor = PitchGreenLight,
              counter = playerEvents.count { it.eventType == EventType.BALL_RECOVERY.name },
              modifier = Modifier.weight(1f),
              testTag = "btn_ball_recovery"
            )
          }
        }

        // GOAL & OPPONENT GOAL BUTTONS
        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = { viewModel.showGoalDialog(true) },
              colors = ButtonDefaults.buttonColors(containerColor = PitchGreenDark),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .weight(1.3f)
                .height(60.dp)
                .testTag("btn_record_goal")
            ) {
              Text(
                text = "⚽ ${s.recordGoal}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                color = Color.White
              )
            }

            OutlinedButton(
              onClick = { viewModel.recordOpponentGoal() },
              shape = RoundedCornerShape(12.dp),
              border = androidx.compose.foundation.BorderStroke(1.dp, StatDangerRed.copy(alpha = 0.5f)),
              modifier = Modifier
                .weight(1f)
                .height(60.dp)
                .testTag("btn_opponent_goal")
            ) {
              Text(
                text = s.addOpponentGoal,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = StatDangerRed,
                textAlign = TextAlign.Center
              )
            }
          }
        }

        // EXPANDED ADVANCED STATS SECTION (Progressive Disclosure)
        if (showMoreStats) {
          item {
            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFF1E293B))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "🎯 ${s.catAttack} & ${s.catPositionTactical}",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = TacticalCyan
            )
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statBigChance,
                icon = Icons.Default.SportsSoccer,
                onClick = { viewModel.recordEvent(EventType.BIG_CHANCE) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statThroughBall,
                icon = Icons.Default.PlayArrow,
                onClick = { viewModel.recordEvent(EventType.THROUGH_BALL) },
                accentColor = TacticalCyan,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statCrossSuccess,
                icon = Icons.Default.SportsSoccer,
                onClick = { viewModel.recordEvent(EventType.CROSS_SUCCESSFUL) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statCrossFailed,
                icon = Icons.Default.Close,
                onClick = { viewModel.recordEvent(EventType.CROSS_FAILED) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statClearance,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.CLEARANCE) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statBlock,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.BLOCK) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statGoodPositioning,
                icon = Icons.Default.Shield,
                onClick = { viewModel.recordEvent(EventType.GOOD_POSITIONING) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statOutOfPosition,
                icon = Icons.Default.Close,
                onClick = { viewModel.recordEvent(EventType.OUT_OF_POSITION) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statSuccessfulPress,
                icon = Icons.Default.PlayArrow,
                onClick = { viewModel.recordEvent(EventType.SUCCESSFUL_PRESS) },
                accentColor = PitchGreenLight,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statFoulCommitted,
                icon = Icons.Default.Close,
                onClick = { viewModel.recordEvent(EventType.FOUL_COMMITTED) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }

          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              LargeStatButton(
                label = s.statYellowCard,
                icon = Icons.Default.NoteAdd,
                onClick = { viewModel.recordEvent(EventType.YELLOW_CARD) },
                accentColor = StatWarningYellow,
                modifier = Modifier.weight(1f)
              )
              LargeStatButton(
                label = s.statRedCard,
                icon = Icons.Default.NoteAdd,
                onClick = { viewModel.recordEvent(EventType.RED_CARD) },
                accentColor = StatDangerRed,
                modifier = Modifier.weight(1f)
              )
            }
          }
        }

        item {
          Spacer(modifier = Modifier.height(20.dp))
        }
      }

      // ─── 5. FIXED BOTTOM ACTIONS: UNDO, SUB, NOTES, HISTORY ───
      Surface(
        color = DarkSurface,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // UNDO LAST EVENT (Most prominent safety button)
          Button(
            onClick = { viewModel.undoLastEvent() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1.3f)
              .height(48.dp)
              .testTag("undo_last_event_button")
          ) {
            Icon(imageVector = Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(s.undo, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }

          // SUBSTITUTION
          OutlinedButton(
            onClick = { viewModel.showSubDialog(true) },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1.1f)
              .height(48.dp)
              .testTag("substitution_button")
          ) {
            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(s.substitution, fontSize = 11.sp, maxLines = 1)
          }

          // NOTES
          IconButton(
            onClick = { viewModel.showNotesDialog(true) },
            modifier = Modifier
              .size(48.dp)
              .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
              .testTag("match_notes_button")
          ) {
            Icon(imageVector = Icons.Default.NoteAdd, contentDescription = "Notes", tint = TacticalCyan)
          }

          // EVENT HISTORY LOG
          IconButton(
            onClick = { viewModel.showEventHistoryDialog(true) },
            modifier = Modifier
              .size(48.dp)
              .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
              .testTag("event_history_button")
          ) {
            Icon(imageVector = Icons.Default.History, contentDescription = "History", tint = PitchGreenLight)
          }
        }
      }
    }

    // ─── 6. FLOATING TOAST FEEDBACK ───
    FloatingFeedbackToast(
      feedback = liveFeedback,
      onDismiss = { /* auto cleared */ },
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(top = 16.dp)
    )
  }

  // ─── DIALOGS & MODAL SHEETS ───

  // GOAL RECORDING DIALOG
  if (showGoalDialog) {
    var selectedScorer by remember { mutableStateOf(selectedPlayer ?: squad.firstOrNull()) }
    var selectedAssist by remember { mutableStateOf<PlayerEntity?>(null) }
    var selectedFinish by remember { mutableStateOf(GoalFinishType.RIGHT_FOOT) }
    var selectedOrigin by remember { mutableStateOf(AttackOrigin.CENTRAL) }

    AlertDialog(
      onDismissRequest = { viewModel.showGoalDialog(false) },
      title = { Text("⚽ ${s.recordGoal}", fontWeight = FontWeight.Bold) },
      text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(350.dp)) {
          item {
            Text(s.scorer, style = MaterialTheme.typography.labelMedium, color = PitchGreenLight)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              items(squad) { p ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedScorer?.id == p.id) PitchGreenDark else Color(0xFF1E293B),
                  modifier = Modifier.clickable { selectedScorer = p }
                ) {
                  Text(
                    text = "#${p.shirtNumber} ${p.name.substringBefore(" ")}",
                    fontSize = 11.sp,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                  )
                }
              }
            }
          }

          item {
            Text(s.assistProvider, style = MaterialTheme.typography.labelMedium, color = TacticalCyan)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              item {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedAssist == null) TacticalCyan.copy(alpha = 0.4f) else Color(0xFF1E293B),
                  modifier = Modifier.clickable { selectedAssist = null }
                ) {
                  Text(s.noAssist, fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
              }
              items(squad.filter { it.id != selectedScorer?.id }) { p ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedAssist?.id == p.id) TacticalCyan else Color(0xFF1E293B),
                  modifier = Modifier.clickable { selectedAssist = p }
                ) {
                  Text("#${p.shirtNumber} ${p.name.substringBefore(" ")}", fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
              }
            }
          }

          item {
            Text(s.goalType, style = MaterialTheme.typography.labelMedium, color = PitchGreenLight)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              GoalFinishType.values().take(4).forEach { f ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedFinish == f) PitchGreenDark else Color(0xFF1E293B),
                  modifier = Modifier.clickable { selectedFinish = f }
                ) {
                  Text(f.name.replace("_", " "), fontSize = 9.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                }
              }
            }
          }

          item {
            Text(s.attackOrigin, style = MaterialTheme.typography.labelMedium, color = PitchGreenLight)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              AttackOrigin.values().take(3).forEach { o ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (selectedOrigin == o) PitchGreenDark else Color(0xFF1E293B),
                  modifier = Modifier.clickable { selectedOrigin = o }
                ) {
                  Text(o.name.replace("_", " "), fontSize = 9.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                }
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            selectedScorer?.let {
              viewModel.recordGoalDetails(it, selectedAssist, selectedFinish, selectedOrigin)
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.confirm)
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.showGoalDialog(false) }) {
          Text(s.cancel)
        }
      }
    )
  }

  // SUBSTITUTION DIALOG
  if (showSubDialog) {
    var outPlayer by remember { mutableStateOf(selectedPlayer ?: squad.firstOrNull()) }
    var inPlayer by remember { mutableStateOf(squad.firstOrNull { it.id != outPlayer?.id }) }

    AlertDialog(
      onDismissRequest = { viewModel.showSubDialog(false) },
      title = { Text("🔄 ${s.substitution}", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(s.subOutTitle, style = MaterialTheme.typography.labelMedium, color = StatDangerRed)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(squad) { p ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (outPlayer?.id == p.id) StatDangerRed else Color(0xFF1E293B),
                modifier = Modifier.clickable { outPlayer = p }
              ) {
                Text("#${p.shirtNumber} ${p.name.substringBefore(" ")}", fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
              }
            }
          }

          Text(s.subInTitle, style = MaterialTheme.typography.labelMedium, color = PitchGreenLight)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(squad.filter { it.id != outPlayer?.id }) { p ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (inPlayer?.id == p.id) PitchGreenDark else Color(0xFF1E293B),
                modifier = Modifier.clickable { inPlayer = p }
              ) {
                Text("#${p.shirtNumber} ${p.name.substringBefore(" ")}", fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (outPlayer != null && inPlayer != null) {
              viewModel.executeSubstitution(outPlayer!!, inPlayer!!)
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.executeSub)
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.showSubDialog(false) }) {
          Text(s.cancel)
        }
      }
    )
  }

  // EVENT HISTORY LOG DIALOG
  if (showHistoryDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.showEventHistoryDialog(false) },
      title = { Text(s.eventHistory, fontWeight = FontWeight.Bold) },
      text = {
        if (events.isEmpty()) {
          Text(s.noEventsRecorded, color = Color.Gray)
        } else {
          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.height(350.dp)
          ) {
            items(events) { ev ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF1E293B),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "${String.format("%02d:%02d", ev.matchMinute, ev.matchSecond)} — #${ev.playerShirtNumber} ${ev.playerName}",
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = PitchGreenLight
                    )
                    Text(
                      text = ev.eventType.replace("_", " "),
                      style = MaterialTheme.typography.bodySmall,
                      color = Color.White
                    )
                  }
                  IconButton(
                    onClick = { viewModel.deleteEvent(ev.id) },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = StatDangerRed, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }
        }
      },
      confirmButton = {
        Button(onClick = { viewModel.showEventHistoryDialog(false) }) {
          Text(s.close)
        }
      }
    )
  }

  // MATCH NOTES DIALOG
  if (showNotesDialog) {
    var noteInput by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { viewModel.showNotesDialog(false) },
      title = { Text(s.matchNotes, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = noteInput,
          onValueChange = { noteInput = it },
          label = { Text(s.addNote) },
          placeholder = { Text(s.notePlaceholder) },
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = { viewModel.addNote(noteInput) },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.save)
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.showNotesDialog(false) }) {
          Text(s.cancel)
        }
      }
    )
  }

  // EXIT LIVE MATCH CONFIRMATION (Prevents accidental loss of match session)
  if (showExitConfirm) {
    AlertDialog(
      onDismissRequest = { viewModel.showExitConfirmDialog(false) },
      title = { Text(s.activeMatchExitTitle, fontWeight = FontWeight.Bold) },
      text = { Text(s.activeMatchExitDesc) },
      confirmButton = {
        Button(
          onClick = { viewModel.confirmExitLiveMatch(saveAndReturnToDashboard = true) },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.saveAndExit)
        }
      },
      dismissButton = {
        Row {
          TextButton(onClick = { viewModel.discardMatch() }) {
            Text(s.cancelMatch, color = StatDangerRed)
          }
          TextButton(onClick = { viewModel.showExitConfirmDialog(false) }) {
            Text(s.continueMatch)
          }
        }
      }
    )
  }

  // END MATCH CONFIRMATION
  if (showEndConfirm) {
    AlertDialog(
      onDismissRequest = { viewModel.showEndMatchConfirmDialog(false) },
      title = { Text(s.endMatchConfirmTitle, fontWeight = FontWeight.Bold) },
      text = { Text(s.endMatchConfirmDesc) },
      confirmButton = {
        Button(
          onClick = { viewModel.finishMatch() },
          colors = ButtonDefaults.buttonColors(containerColor = StatDangerRed)
        ) {
          Text(s.endMatch)
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.showEndMatchConfirmDialog(false) }) {
          Text(s.cancel)
        }
      }
    )
  }
}

@Composable
fun StatBadge(label: String) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = Color(0xFF1E293B)
  ) {
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = Color.White,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
    )
  }
}
