package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MatchEntity
import com.example.data.local.MatchEventEntity
import com.example.data.local.MatchNoteEntity
import com.example.data.local.SubstitutionEntity
import com.example.data.local.TeamEntity
import com.example.i18n.LocalAppStrings
import com.example.model.ActivityPeriodStats
import com.example.model.EventType
import com.example.data.local.PlayerEntity
import com.example.model.PlayerMatchStats
import com.example.model.Position
import com.example.model.StatCategory
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.StadiumAmber
import com.example.ui.theme.StatDangerRed
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MatchDetailScreen(
  matchId: Long,
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val prefs by viewModel.preferences.collectAsState()
  val isArabic = prefs.language == "ar"

  BackHandler {
    viewModel.goBack()
  }

  var match by remember { mutableStateOf<MatchEntity?>(null) }
  var team by remember { mutableStateOf<TeamEntity?>(null) }
  var events by remember { mutableStateOf<List<MatchEventEntity>>(emptyList()) }
  var subs by remember { mutableStateOf<List<SubstitutionEntity>>(emptyList()) }
  var notes by remember { mutableStateOf<List<MatchNoteEntity>>(emptyList()) }
  var playerStatsList by remember { mutableStateOf<List<PlayerMatchStats>>(emptyList()) }
  var activityPeriods by remember { mutableStateOf<List<ActivityPeriodStats>>(emptyList()) }

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Summary, 1: Players, 2: Timeline, 3: Trends

  LaunchedEffect(matchId) {
    val m = viewModel.repository.getMatchById(matchId)
    match = m
    if (m != null) {
      val t = viewModel.repository.getFirstTeam()
      team = t
      val evs = viewModel.repository.getEventsForMatchList(matchId)
      events = evs
      subs = viewModel.repository.getSubstitutionsForMatchList(matchId)
      val pList = viewModel.repository.getPlayersForTeamList(m.teamId)
      playerStatsList = pList.map { p ->
        viewModel.repository.calculatePlayerStats(m.id, p, m.matchDurationMinutes)
      }.sortedByDescending { it.minutesPlayed }
      activityPeriods = viewModel.repository.calculateActivityPeriods(matchId)
    }
  }

  if (match == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("Loading report...", color = Color.White)
    }
    return
  }

  val m = match!!
  val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(m.matchDate))

  // Key Aggregations
  val totalShots = events.count { it.category == StatCategory.ATTACK.name && (it.eventType.contains("SHOT") || it.eventType.contains("GOAL")) }
  val shotsOnTarget = events.count { it.eventType == EventType.SHOT_ON_TARGET.name || it.eventType == EventType.GOAL.name }
  val passesCompleted = events.count { it.eventType == EventType.PASS_COMPLETED.name }
  val passesFailed = events.count { it.eventType == EventType.PASS_FAILED.name }
  val totalPasses = passesCompleted + passesFailed
  val passAccuracy = if (totalPasses > 0) (passesCompleted * 100f / totalPasses).toInt() else 0
  val dribblesSuccessful = events.count { it.eventType == EventType.SUCCESSFUL_DRIBBLE.name }
  val ballLosses = events.count { it.eventType == EventType.BALL_LOST.name || it.eventType == EventType.DISPOSSESSED.name }
  val tacklesWon = events.count { it.eventType == EventType.TACKLE_WON.name }
  val interceptions = events.count { it.eventType == EventType.INTERCEPTION.name }
  val clearances = events.count { it.eventType == EventType.CLEARANCE.name }
  val yellowCards = events.count { it.eventType == EventType.YELLOW_CARD.name }
  val redCards = events.count { it.eventType == EventType.RED_CARD.name }

  // Top Performers
  val topPasser = playerStatsList.filter { it.totalPasses > 0 }.maxByOrNull { it.passAccuracyPercent }
  val topDribbler = playerStatsList.maxByOrNull { it.dribblesSuccessful }
  val topTackler = playerStatsList.maxByOrNull { it.tacklesWon }
  val mostActive = playerStatsList.maxByOrNull { it.totalActions }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))

    // Top Navigation & Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { viewModel.goBack() }) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = s.matchReport,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      // Share & Export Actions
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        IconButton(
          onClick = {
            coroutineScope.launch {
              val csv = viewModel.repository.exportMatchCsv(matchId)
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, csv)
                type = "text/csv"
              }
              val shareIntent = Intent.createChooser(sendIntent, s.exportCsv)
              context.startActivity(shareIntent)
            }
          },
          modifier = Modifier
            .size(38.dp)
            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
            .testTag("export_csv_button")
        ) {
          Icon(imageVector = Icons.Default.FileDownload, contentDescription = s.exportCsv, tint = TacticalCyan)
        }

        IconButton(
          onClick = {
            coroutineScope.launch {
              val reportText = viewModel.repository.formatMatchReportText(matchId, isArabic)
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, reportText)
                type = "text/plain"
              }
              val shareIntent = Intent.createChooser(sendIntent, s.share)
              context.startActivity(shareIntent)
            }
          },
          modifier = Modifier
            .size(38.dp)
            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
            .testTag("share_report_button")
        ) {
          Icon(imageVector = Icons.Default.Share, contentDescription = s.share, tint = PitchGreenLight)
        }
      }
    }

    // Scoreboard Hero Banner
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenPrimary.copy(alpha = 0.3f)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "${m.competition} • $dateStr",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Text(
              text = team?.name ?: s.ourTeam,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              textAlign = TextAlign.Center,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(text = "Formation: ${m.formation}", fontSize = 11.sp, color = PitchGreenLight)
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = PitchGreenDark,
            modifier = Modifier.padding(horizontal = 8.dp)
          ) {
            Text(
              text = "${m.ourScore} - ${m.opponentScore}",
              style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
              color = Color.White,
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Text(
              text = m.opponentName,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(text = "${m.matchDurationMinutes} mins", fontSize = 11.sp, color = Color.Gray)
          }
        }
      }
    }

    // Sub Tabs
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surfaceVariant,
      contentColor = PitchGreenLight
    ) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Overview", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text(s.players, fontSize = 12.sp, fontWeight = FontWeight.Bold) })
      Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Timeline", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
      Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Trend", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
    }

    Spacer(modifier = Modifier.height(10.dp))

    // TAB CONTENTS
    when (selectedTab) {
      0 -> {
        // OVERVIEW TAB: Team Stats Comparison & Top Performers
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
          item {
            Text(s.topPerformers, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = PitchGreenLight)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              mostActive?.let { p ->
                TopStatCard(title = s.mostActivePlayers, name = "#${p.shirtNumber} ${p.playerName.substringBefore(" ")}", stat = "${p.totalActions} acts", color = PitchGreenLight, modifier = Modifier.weight(1f))
              }
              topPasser?.let { p ->
                TopStatCard(title = s.bestPassers, name = "#${p.shirtNumber} ${p.playerName.substringBefore(" ")}", stat = "${p.passAccuracyPercent.toInt()}%", color = TacticalCyan, modifier = Modifier.weight(1f))
              }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              topDribbler?.let { p ->
                TopStatCard(title = s.topDribblers, name = "#${p.shirtNumber} ${p.playerName.substringBefore(" ")}", stat = "${p.dribblesSuccessful} won", color = StadiumAmber, modifier = Modifier.weight(1f))
              }
              topTackler?.let { p ->
                TopStatCard(title = s.mostDefensiveActions, name = "#${p.shirtNumber} ${p.playerName.substringBefore(" ")}", stat = "${p.tacklesWon} tkl", color = StatDangerRed, modifier = Modifier.weight(1f))
              }
            }
          }

          item {
            Text("📊 Match Aggregations", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = PitchGreenLight)
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StatRowItem(label = "Goals Scored", value = "${m.ourScore}")
                StatRowItem(label = "Total Shots (On Target)", value = "$totalShots ($shotsOnTarget)")
                StatRowItem(label = "Pass Accuracy", value = "$passAccuracy% ($passesCompleted / $totalPasses)")
                StatRowItem(label = "Successful Dribbles", value = "$dribblesSuccessful")
                StatRowItem(label = "Ball Losses", value = "$ballLosses")
                StatRowItem(label = "Tackles Won", value = "$tacklesWon")
                StatRowItem(label = "Interceptions & Clearances", value = "${interceptions + clearances}")
                StatRowItem(label = "Cards", value = "🟨 $yellowCards | 🟥 $redCards")
              }
            }
          }

          // Attack Origins Analysis
          item {
            Text(s.attackPatterns, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = TacticalCyan)
            val leftWingAttacks = events.count { it.zone?.contains("LEFT") == true && it.category == StatCategory.ATTACK.name }
            val rightWingAttacks = events.count { it.zone?.contains("RIGHT") == true && it.category == StatCategory.ATTACK.name }
            val centralAttacks = events.count { it.zone?.contains("CENTER") == true && it.category == StatCategory.ATTACK.name }

            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "• Left Wing: $leftWingAttacks recorded attacks\n• Central Penetration: $centralAttacks recorded attacks\n• Right Wing: $rightWingAttacks recorded attacks",
                  style = MaterialTheme.typography.bodyMedium,
                  color = Color.White
                )
              }
            }
          }

          item { Spacer(modifier = Modifier.height(30.dp)) }
        }
      }

      1 -> {
        // PLAYERS STATS TABLE TAB
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
          items(playerStatsList) { p ->
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.PlayerProfile(p.playerId)) }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(34.dp)
                      .clip(CircleShape)
                      .background(if (p.position == Position.GK) TacticalCyan else PitchGreenDark),
                    contentAlignment = Alignment.Center
                  ) {
                    Text("#${p.shirtNumber}", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color.White)
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(text = p.playerName, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(text = "${p.position} • ${p.minutesPlayed} mins", fontSize = 11.sp, color = Color.Gray)
                  }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Column(horizontalAlignment = Alignment.End) {
                    Text("⚽ ${p.goals}  🎯 ${p.shotsOnTarget}", fontSize = 11.sp, color = PitchGreenLight, fontWeight = FontWeight.Bold)
                    Text("Pass: ${p.passAccuracyPercent.toInt()}% (${p.passesCompleted})", fontSize = 11.sp, color = Color.LightGray)
                  }
                }
              }
            }
          }
          item { Spacer(modifier = Modifier.height(30.dp)) }
        }
      }

      2 -> {
        // TIMELINE TAB
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
          if (events.isEmpty()) {
            item { Text(s.noEventsRecorded, color = Color.Gray) }
          } else {
            items(events.reversed()) { ev ->
              Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "${String.format("%02d:%02d", ev.matchMinute, ev.matchSecond)}'",
                      fontWeight = FontWeight.Black,
                      color = PitchGreenLight,
                      fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = "#${ev.playerShirtNumber} ${ev.playerName}",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                      Text(
                        text = ev.eventType.replace("_", " "),
                        fontSize = 11.sp,
                        color = if (ev.eventType.contains("GOAL")) PitchGreenLight else Color.LightGray
                      )
                    }
                  }
                  if (ev.zone != null) {
                    Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF1E293B)) {
                      Text(ev.zone, fontSize = 9.sp, color = Color.Gray, modifier = Modifier.padding(4.dp))
                    }
                  }
                }
              }
            }
          }
          item { Spacer(modifier = Modifier.height(30.dp)) }
        }
      }

      3 -> {
        // TREND & ACTIVITY PERIODS TAB (0-15, 15-30, etc.)
        val trendSummary = viewModel.repository.generateActivityTrendSummary(activityPeriods, isArabic)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
          item {
            Text(s.recordedActivityTrend, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = PitchGreenLight)
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF131C2A)),
              border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenPrimary.copy(alpha = 0.3f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = trendSummary,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier.padding(14.dp)
              )
            }
          }

          item {
            Text("Activity By 15-Minute Periods", style = MaterialTheme.typography.labelMedium, color = TacticalCyan)
          }

          items(activityPeriods) { period ->
            Card(
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(period.periodLabel, fontWeight = FontWeight.Bold, color = PitchGreenLight)
                Text("Actions: ${period.totalActions}", fontWeight = FontWeight.SemiBold, color = Color.White)
                Text("Success: ${period.successfulActions}", fontSize = 11.sp, color = Color(0xFFA7F3D0))
                Text("Losses: ${period.ballLosses}", fontSize = 11.sp, color = StatDangerRed)
              }
            }
          }

          item { Spacer(modifier = Modifier.height(30.dp)) }
        }
      }
    }
  }
}

@Composable
fun TopStatCard(title: String, name: String, stat: String, color: Color, modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Text(title, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
      Spacer(modifier = Modifier.height(2.dp))
      Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White, maxLines = 1)
      Text(stat, fontWeight = FontWeight.Black, fontSize = 14.sp, color = color)
    }
  }
}

@Composable
fun StatRowItem(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, fontSize = 12.sp, color = Color.LightGray)
    Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
  }
}
