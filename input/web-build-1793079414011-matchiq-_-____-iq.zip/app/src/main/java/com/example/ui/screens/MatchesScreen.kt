package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.LocalAppStrings
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.TacticalCyan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MatchesScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val matches by viewModel.allMatches.collectAsState()
  val teams by viewModel.allTeams.collectAsState()
  val team = teams.firstOrNull()
  var selectedTab by remember { mutableIntStateOf(0) } // 0: All, 1: Live, 2: Finished

  val filteredMatches = when (selectedTab) {
    1 -> matches.filter { it.isLive }
    2 -> matches.filter { it.isFinished }
    else -> matches
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = { viewModel.navigateTo(Screen.CreateMatch) },
        containerColor = PitchGreenPrimary,
        contentColor = Color.White,
        modifier = Modifier.testTag("create_match_fab")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "Create Match")
      }
    },
    modifier = modifier.fillMaxSize()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp)
    ) {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = s.matches,
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(10.dp))

      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = PitchGreenLight
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text(s.all, fontWeight = FontWeight.Bold) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Live", fontWeight = FontWeight.Bold) }
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text("Finished", fontWeight = FontWeight.Bold) }
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredMatches.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.SportsSoccer,
              contentDescription = null,
              tint = Color.Gray,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(s.noMatchesYet, color = Color.Gray)
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.weight(1f)
        ) {
          items(filteredMatches) { m ->
            val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(m.matchDate))
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (m.isLive) Color(0xFF064E3B) else MaterialTheme.colorScheme.surfaceVariant
              ),
              border = if (m.isLive) androidx.compose.foundation.BorderStroke(2.dp, PitchGreenLight) else null,
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  if (m.isLive) viewModel.navigateTo(Screen.LiveMatch(m.id))
                  else viewModel.navigateTo(Screen.MatchDetail(m.id))
                }
                .testTag("match_item_${m.id}")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    if (m.isLive) {
                      Box(
                        modifier = Modifier
                          .size(8.dp)
                          .clip(CircleShape)
                          .background(PitchGreenLight)
                      )
                      Spacer(modifier = Modifier.width(6.dp))
                      Text("LIVE", color = PitchGreenLight, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                      Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                      text = m.competition,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = team?.name ?: s.ourTeam,
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = Color.White
                    )
                    Text(
                      text = m.opponentName,
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                      text = "${m.venue} • ${if (m.isHome) s.homeMatch else s.awayMatch}",
                      style = MaterialTheme.typography.bodySmall,
                      color = Color.Gray
                    )
                  }

                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (m.isLive) Color.Black.copy(alpha = 0.5f) else PitchGreenDark,
                    modifier = Modifier.padding(start = 12.dp)
                  ) {
                    Text(
                      text = "${m.ourScore} - ${m.opponentScore}",
                      style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.End
                ) {
                  Text(
                    text = if (m.isLive) "${s.resumeMatch} ➔" else "${s.fullMatchReport} ➔",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (m.isLive) PitchGreenLight else TacticalCyan
                  )
                }
              }
            }
          }
          item { Spacer(modifier = Modifier.height(80.dp)) }
        }
      }
    }
  }
}
