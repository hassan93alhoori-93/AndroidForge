package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MatchEventEntity
import com.example.i18n.LocalAppStrings
import com.example.data.local.PlayerEntity
import com.example.model.PlayerMatchStats
import com.example.model.Position
import com.example.ui.MatchIQViewModel
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.StatDangerRed
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch

@Composable
fun PlayerProfileScreen(
  playerId: Long,
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val coroutineScope = rememberCoroutineScope()
  val prefs by viewModel.preferences.collectAsState()
  val isArabic = prefs.language == "ar"

  BackHandler {
    viewModel.goBack()
  }

  var player by remember { mutableStateOf<PlayerEntity?>(null) }
  var playerEvents by remember { mutableStateOf<List<MatchEventEntity>>(emptyList()) }
  var aggregateStats by remember { mutableStateOf<PlayerMatchStats?>(null) }
  var showDeleteDialog by remember { mutableStateOf(false) }

  LaunchedEffect(playerId) {
    val p = viewModel.repository.getPlayerById(playerId)
    player = p
    if (p != null) {
      val evs = viewModel.repository.getEventsForPlayerList(playerId)
      playerEvents = evs
      val latestMatch = viewModel.repository.getLatestFinishedMatchOnce()
      val mId = latestMatch?.id ?: 1L
      val stats = viewModel.repository.calculatePlayerStats(mId, p, 90)
      aggregateStats = stats
    }
  }

  if (player == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("Loading player profile...", color = Color.White)
    }
    return
  }

  val p = player!!
  val isGk = p.position == Position.GK.name

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))

    // Top Navigation
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { viewModel.goBack() }) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = s.playerReport,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      IconButton(
        onClick = { showDeleteDialog = true },
        modifier = Modifier.testTag("delete_player_button")
      ) {
        Icon(imageVector = Icons.Default.Delete, contentDescription = s.delete, tint = StatDangerRed)
      }
    }

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      // Player Hero Header Card
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenPrimary.copy(alpha = 0.35f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(if (isGk) TacticalCyan else PitchGreenDark),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "#${p.shirtNumber}",
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = Color.White
              )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text(
                text = p.name,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "Position: ${p.position} • Preferred Foot: ${p.preferredFoot}",
                style = MaterialTheme.typography.bodyMedium,
                color = PitchGreenLight
              )
              Text(
                text = "Status: ${if (p.isStarter) s.startingXI else s.substitutes} • Active Events: ${playerEvents.size}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
              )
            }
          }
        }
      }

      // Statistical Breakdown Card
      aggregateStats?.let { stats ->
        item {
          Text("📊 Performance Statistics", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = PitchGreenLight)
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              if (isGk) {
                StatRowItem(label = "Goalkeeper Saves", value = "${stats.gkSaves}")
                StatRowItem(label = "Dangerous Saves", value = "${stats.gkDangerousSaves}")
                StatRowItem(label = "Goals Conceded", value = "${stats.gkGoalsConceded}")
                StatRowItem(label = "Clean Sheet", value = if (stats.gkCleanSheet) "Yes ✓" else "No")
              } else {
                StatRowItem(label = "Goals", value = "${stats.goals}")
                StatRowItem(label = "Assists", value = "${stats.assists}")
                StatRowItem(label = "Pass Accuracy", value = "${stats.passAccuracyPercent.toInt()}% (${stats.passesCompleted}/${stats.totalPasses})")
                StatRowItem(label = "Successful Dribbles", value = "${stats.dribblesSuccessful} (${stats.dribbleSuccessPercent.toInt()}%)")
                StatRowItem(label = "Shots (On Target)", value = "${stats.totalShots} (${stats.shotsOnTarget})")
                StatRowItem(label = "Ball Recoveries", value = "${stats.ballRecoveries}")
                StatRowItem(label = "Ball Losses", value = "${stats.ballLosses}")
                StatRowItem(label = "Tackles Won", value = "${stats.tacklesWon}")
                StatRowItem(label = "Interceptions", value = "${stats.interceptions}")
                StatRowItem(label = "Disciplinary", value = "🟨 ${stats.yellowCards} | 🟥 ${stats.redCards}")
              }
            }
          }
        }
      }

      // Recent Recorded Events for this player
      item {
        Text("Recorded Match Actions (${playerEvents.size})", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = TacticalCyan)
      }

      if (playerEvents.isEmpty()) {
        item { Text(s.noEventsRecorded, color = Color.Gray) }
      } else {
        items(playerEvents.take(15)) { ev ->
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF1E293B),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${String.format("%02d:%02d", ev.matchMinute, ev.matchSecond)}' — ${ev.eventType.replace("_", " ")}",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                color = Color.White
              )
              if (ev.zone != null) {
                Text(ev.zone, fontSize = 10.sp, color = PitchGreenLight)
              }
            }
          }
        }
      }

      item { Spacer(modifier = Modifier.height(30.dp)) }
    }
  }

  // Delete Player Dialog
  if (showDeleteDialog) {
    AlertDialog(
      onDismissRequest = { showDeleteDialog = false },
      title = { Text(s.delete, fontWeight = FontWeight.Bold) },
      text = { Text("Are you sure you want to remove ${p.name} from the squad?") },
      confirmButton = {
        Button(
          onClick = {
            coroutineScope.launch {
              viewModel.repository.deletePlayer(p.id)
              showDeleteDialog = false
              viewModel.goBack()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = StatDangerRed)
        ) {
          Text(s.delete)
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteDialog = false }) {
          Text(s.cancel)
        }
      }
    )
  }
}
