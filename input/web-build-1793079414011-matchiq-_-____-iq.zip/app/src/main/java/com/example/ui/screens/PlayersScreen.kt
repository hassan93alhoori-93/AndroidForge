package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.LocalAppStrings
import com.example.data.local.PlayerEntity
import com.example.model.Position
import com.example.model.PreferredFoot
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch

@Composable
fun PlayersScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val teams by viewModel.allTeams.collectAsState()
  val team = teams.firstOrNull()
  val coroutineScope = rememberCoroutineScope()

  var squad by remember { mutableStateOf<List<PlayerEntity>>(emptyList()) }
  var selectedPositionFilter by remember { mutableStateOf("ALL") }
  var showAddPlayerDialog by remember { mutableStateOf(false) }

  androidx.compose.runtime.LaunchedEffect(team) {
    if (team != null) {
      squad = viewModel.repository.getPlayersForTeamList(team.id)
    }
  }

  val filteredSquad = when (selectedPositionFilter) {
    "GK" -> squad.filter { it.position == Position.GK.name }
    "DEF" -> squad.filter { it.position in listOf(Position.CB.name, Position.LB.name, Position.RB.name, Position.LWB.name, Position.RWB.name) }
    "MID" -> squad.filter { it.position in listOf(Position.DM.name, Position.CM.name, Position.AM.name) }
    "FWD" -> squad.filter { it.position in listOf(Position.LW.name, Position.RW.name, Position.ST.name, Position.CF.name) }
    else -> squad
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddPlayerDialog = true },
        containerColor = PitchGreenPrimary,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_player_fab")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = s.addPlayer)
      }
    },
    modifier = modifier.fillMaxSize()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp)
    ) {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "${s.players} (${squad.size})",
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(10.dp))

      // Position Filter Chips
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val filters = listOf("ALL", "GK", "DEF", "MID", "FWD")
        items(filters) { f ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (selectedPositionFilter == f) PitchGreenDark else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clickable { selectedPositionFilter = f }
          ) {
            Text(
              text = f,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        items(filteredSquad) { p ->
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { viewModel.navigateTo(Screen.PlayerProfile(p.id)) }
              .testTag("player_card_${p.shirtNumber}")
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (p.position == Position.GK.name) TacticalCyan else PitchGreenDark),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "#${p.shirtNumber}",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = Color.White
                  )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = p.name,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp
                  )
                  Text(
                    text = "${p.position} • Preferred Foot: ${p.preferredFoot}",
                    fontSize = 11.sp,
                    color = Color.Gray
                  )
                }
              }

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (p.isStarter) PitchGreenPrimary.copy(alpha = 0.2f) else Color(0xFF1E293B)
              ) {
                Text(
                  text = if (p.isStarter) s.startingXI else s.substitutes,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (p.isStarter) PitchGreenLight else Color.LightGray,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
        item { Spacer(modifier = Modifier.height(80.dp)) }
      }
    }
  }

  // Add Player Dialog
  if (showAddPlayerDialog && team != null) {
    var pName by remember { mutableStateOf("") }
    var pNumber by remember { mutableStateOf("10") }
    var pPos by remember { mutableStateOf(Position.CM) }
    var pFoot by remember { mutableStateOf(PreferredFoot.RIGHT) }

    AlertDialog(
      onDismissRequest = { showAddPlayerDialog = false },
      title = { Text(s.addPlayer, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = pName,
            onValueChange = { pName = it },
            label = { Text(s.playerName) },
            modifier = Modifier.fillMaxWidth().testTag("add_player_name_input")
          )
          OutlinedTextField(
            value = pNumber,
            onValueChange = { pNumber = it },
            label = { Text(s.shirtNumber) },
            modifier = Modifier.fillMaxWidth().testTag("add_player_number_input")
          )

          Text(s.position, style = MaterialTheme.typography.labelSmall, color = PitchGreenLight)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Position.values()) { pos ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (pPos == pos) PitchGreenDark else Color(0xFF1E293B),
                modifier = Modifier.clickable { pPos = pos }
              ) {
                Text(pos.name, fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
              }
            }
          }

          Text(s.preferredFoot, style = MaterialTheme.typography.labelSmall, color = TacticalCyan)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PreferredFoot.values().forEach { foot ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (pFoot == foot) TacticalCyan else Color(0xFF1E293B),
                modifier = Modifier.clickable { pFoot = foot }
              ) {
                Text(foot.name, fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (pName.isNotBlank()) {
              coroutineScope.launch {
                val num = pNumber.toIntOrNull() ?: (squad.size + 1)
                viewModel.repository.savePlayer(
                  PlayerEntity(
                    teamId = team.id,
                    name = pName.trim(),
                    shirtNumber = num,
                    position = pPos.name,
                    preferredFoot = pFoot.name,
                    isStarter = false,
                    orderIndex = squad.size
                  )
                )
                squad = viewModel.repository.getPlayersForTeamList(team.id)
                showAddPlayerDialog = false
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.save)
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddPlayerDialog = false }) {
          Text(s.cancel)
        }
      }
    )
  }
}
