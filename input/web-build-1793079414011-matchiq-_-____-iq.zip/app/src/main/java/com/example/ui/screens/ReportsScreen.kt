package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MatchEntity
import com.example.data.local.TeamEntity
import com.example.i18n.LocalAppStrings
import com.example.model.PlayerMatchStats
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch

@Composable
fun ReportsScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val prefs by viewModel.preferences.collectAsState()
  val isArabic = prefs.language == "ar"

  val matches by viewModel.allMatches.collectAsState()
  val teams by viewModel.allTeams.collectAsState()
  val team = teams.firstOrNull()

  var selectedReportType by remember { mutableIntStateOf(0) }
  val reportTypes = listOf(
    s.matchReport,
    s.playerReport,
    s.teamReport,
    s.seasonReport,
    s.goalkeeperReport,
    s.attackingReport,
    s.defensiveReport,
    s.passingReport
  )

  val latestMatch = matches.firstOrNull { it.isFinished } ?: matches.firstOrNull()

  var previewReportText by remember { mutableStateOf("") }

  LaunchedEffect(selectedReportType, latestMatch, isArabic) {
    if (latestMatch != null) {
      previewReportText = viewModel.repository.formatMatchReportText(latestMatch.id, isArabic)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))
    Text(
      text = s.reports,
      style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
      color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(10.dp))

    // Report Type Filter Chips
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(reportTypes.indices.toList()) { index ->
        val isSelected = selectedReportType == index
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isSelected) PitchGreenDark else MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .clickable { selectedReportType = index }
            .testTag("report_type_chip_$index")
        ) {
          Text(
            text = reportTypes[index],
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.weight(1f)
    ) {
      // Export & Share Action Bar Card
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = {
                if (latestMatch != null) {
                  coroutineScope.launch {
                    val reportText = viewModel.repository.formatMatchReportText(latestMatch.id, isArabic)
                    val sendIntent = Intent().apply {
                      action = Intent.ACTION_SEND
                      putExtra(Intent.EXTRA_TEXT, reportText)
                      type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, s.share))
                  }
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .testTag("reports_share_button")
            ) {
              Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(s.share, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            OutlinedButton(
              onClick = {
                if (latestMatch != null) {
                  coroutineScope.launch {
                    val csv = viewModel.repository.exportMatchCsv(latestMatch.id)
                    val sendIntent = Intent().apply {
                      action = Intent.ACTION_SEND
                      putExtra(Intent.EXTRA_TEXT, csv)
                      type = "text/csv"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, s.exportCsv))
                  }
                }
              },
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .testTag("reports_export_csv_button")
            ) {
              Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(s.exportCsv, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }

      // Report Live Preview Card
      item {
        Text(
          text = "${reportTypes[selectedReportType]} (Preview)",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = PitchGreenLight
        )
      }

      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
          border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenPrimary.copy(alpha = 0.25f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = previewReportText.ifEmpty { "Generating report analytics..." },
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White,
            modifier = Modifier.padding(16.dp)
          )
        }
      }

      // Recent Matches to run report on
      item {
        Text(
          text = "Select Match for Report",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = TacticalCyan
        )
      }

      items(matches) { m ->
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.navigateTo(Screen.MatchDetail(m.id)) }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("${team?.name ?: s.ourTeam} vs ${m.opponentName}", fontWeight = FontWeight.Bold, color = Color.White)
              Text("${m.competition} • ${m.ourScore}-${m.opponentScore}", fontSize = 11.sp, color = Color.Gray)
            }
            Text("Open ➔", color = PitchGreenLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      item { Spacer(modifier = Modifier.height(30.dp)) }
    }
  }
}
