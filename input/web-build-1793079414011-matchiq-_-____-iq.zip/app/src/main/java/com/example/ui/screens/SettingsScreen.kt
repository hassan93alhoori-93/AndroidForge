package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.LocalAppStrings
import com.example.ui.MatchIQViewModel
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.StatDangerRed
import com.example.ui.theme.TacticalCyan

@Composable
fun SettingsScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val context = LocalContext.current
  val prefs by viewModel.preferences.collectAsState()
  var showResetConfirmDialog by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))
    Text(
      text = s.settings,
      style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
      color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(14.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      // 1. Language Switcher (Arabic RTL vs English LTR)
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = TacticalCyan)
              Spacer(modifier = Modifier.padding(start = 8.dp))
              Text(
                text = s.language,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (prefs.language == "ar") PitchGreenDark else Color(0xFF1E293B),
                modifier = Modifier
                  .weight(1f)
                  .clickable { viewModel.setLanguage(AppLanguage.ARABIC) }
                  .testTag("lang_arabic_button")
              ) {
                Text(
                  text = "العربية (RTL)",
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  fontSize = 14.sp,
                  modifier = Modifier.padding(vertical = 12.dp, horizontal = 14.dp)
                )
              }

              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (prefs.language == "en") PitchGreenDark else Color(0xFF1E293B),
                modifier = Modifier
                  .weight(1f)
                  .clickable { viewModel.setLanguage(AppLanguage.ENGLISH) }
                  .testTag("lang_english_button")
              ) {
                Text(
                  text = "English (LTR)",
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  fontSize = 14.sp,
                  modifier = Modifier.padding(vertical = 12.dp, horizontal = 14.dp)
                )
              }
            }
          }
        }
      }

      // 2. Appearance & Sideline Usability
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.DarkMode, contentDescription = null, tint = PitchGreenLight)
              Spacer(modifier = Modifier.padding(start = 8.dp))
              Text(
                text = s.appearance,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(s.darkMode, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text("Optimized for pitch sideline high-contrast", fontSize = 11.sp, color = Color.Gray)
              }
              Switch(
                checked = prefs.isDarkMode,
                onCheckedChange = { viewModel.toggleDarkMode(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = PitchGreenLight, checkedTrackColor = PitchGreenDark)
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(s.hapticFeedback, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text("Instant tactile confirmation on stat tap", fontSize = 11.sp, color = Color.Gray)
              }
              Switch(
                checked = prefs.hapticFeedback,
                onCheckedChange = { viewModel.toggleHaptic(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = PitchGreenLight, checkedTrackColor = PitchGreenDark)
              )
            }
          }
        }
      }

      // 3. Data Safety & Offline First
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = TacticalCyan)
              Spacer(modifier = Modifier.padding(start = 8.dp))
              Text(
                text = s.dataManagement,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
            Text(
              text = "• 100% Offline First: All matches and player statistics are securely kept on your device.\n• No external data transmission without your consent.\n• Fast SQLite/Room database storage.",
              style = MaterialTheme.typography.bodySmall,
              color = Color.LightGray
            )

            Button(
              onClick = { showResetConfirmDialog = true },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(s.restoreDemo, fontSize = 12.sp)
            }
          }
        }
      }

      // 4. About MATCHIQ & Future Monetization / Architecture
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = PitchGreenLight)
              Spacer(modifier = Modifier.padding(start = 8.dp))
              Text(
                text = "${s.aboutMatchIQ} | ${s.appVersion}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "MATCHIQ is engineered for football coaches to record match events instantaneously on the sideline without paper forms. Built with Kotlin, Jetpack Compose, and offline Room database.",
              style = MaterialTheme.typography.bodySmall,
              color = Color.LightGray
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(30.dp)) }
    }
  }

  if (showResetConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showResetConfirmDialog = false },
      title = { Text(s.restoreDemo, fontWeight = FontWeight.Bold) },
      text = { Text("This will reload the complete demo squad (18 players) and demo match events. Continue?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.resetToDemoData()
            showResetConfirmDialog = false
            Toast.makeText(context, "Demo data reloaded successfully!", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.confirm)
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetConfirmDialog = false }) {
          Text(s.cancel)
        }
      }
    )
  }
}
