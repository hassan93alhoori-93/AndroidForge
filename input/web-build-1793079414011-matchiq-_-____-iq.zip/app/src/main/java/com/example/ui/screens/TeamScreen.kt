package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.TeamEntity
import com.example.i18n.LocalAppStrings
import com.example.data.local.PlayerEntity
import com.example.model.Position
import com.example.ui.MatchIQViewModel
import com.example.ui.Screen
import com.example.ui.theme.PitchGreenDark
import com.example.ui.theme.PitchGreenLight
import com.example.ui.theme.PitchGreenPrimary
import com.example.ui.theme.TacticalCyan
import kotlinx.coroutines.launch

@Composable
fun TeamScreen(
  viewModel: MatchIQViewModel,
  modifier: Modifier = Modifier
) {
  val s = LocalAppStrings.current
  val teams by viewModel.allTeams.collectAsState()
  val team = teams.firstOrNull()
  val coroutineScope = rememberCoroutineScope()

  var showEditDialog by remember { mutableStateOf(false) }
  var squad by remember { mutableStateOf<List<PlayerEntity>>(emptyList()) }

  androidx.compose.runtime.LaunchedEffect(team) {
    if (team != null) {
      squad = viewModel.repository.getPlayersForTeamList(team.id)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))

    // Top Title & Edit Action
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = s.team,
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
        color = MaterialTheme.colorScheme.onSurface
      )
      IconButton(
        onClick = { showEditDialog = true },
        modifier = Modifier.testTag("edit_team_button")
      ) {
        Icon(imageVector = Icons.Default.Edit, contentDescription = s.edit, tint = TacticalCyan)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    if (team == null) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("No team found. Please initialize demo team.", color = Color.White)
      }
      return
    }

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      // Team Metadata Card
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = team.name,
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
              color = PitchGreenLight
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "${team.ageCategory} • Season ${team.season}",
              style = MaterialTheme.typography.bodyMedium,
              color = Color.LightGray
            )
            Text(
              text = "Head Coach: ${team.coachName}",
              style = MaterialTheme.typography.bodySmall,
              color = Color.Gray
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = PitchGreenPrimary.copy(alpha = 0.2f)
              ) {
                Text(
                  text = "Formation: ${team.defaultFormation}",
                  fontWeight = FontWeight.Bold,
                  color = PitchGreenLight,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  fontSize = 12.sp
                )
              }
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = TacticalCyan.copy(alpha = 0.2f)
              ) {
                Text(
                  text = "Squad: ${squad.size} Players",
                  fontWeight = FontWeight.Bold,
                  color = TacticalCyan,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  fontSize = 12.sp
                )
              }
            }
          }
        }
      }

      // Tactical Board Pitch Graphic Preview
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
          border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenDark),
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            Image(
              painter = painterResource(id = R.drawable.pitch_tactical_bg),
              contentDescription = "Tactical Pitch",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.25f))
                .padding(12.dp)
            ) {
              Text(
                text = "TACTICAL BOARD • ${team.defaultFormation}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                color = PitchGreenLight,
                modifier = Modifier.align(Alignment.TopStart)
              )
              // Formation badges on pitch
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .align(Alignment.Center),
                horizontalArrangement = Arrangement.SpaceEvenly
              ) {
                FormationPill("GK")
                FormationPill("DEF (4)")
                FormationPill("MID (3)")
                FormationPill("FWD (3)")
              }
            }
          }
        }
      }

      // Squad Roster List
      item {
        Text(
          text = "${s.players} (${squad.size})",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      items(squad) { player ->
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.navigateTo(Screen.PlayerProfile(player.id)) }
            .testTag("squad_player_${player.shirtNumber}")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(if (player.position == Position.GK.name) TacticalCyan else PitchGreenDark),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "#${player.shirtNumber}",
                  fontWeight = FontWeight.Black,
                  fontSize = 13.sp,
                  color = Color.White
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = player.name,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = "${player.position} • Foot: ${player.preferredFoot} • ${if (player.isStarter) s.startingXI else s.substitutes}",
                  fontSize = 11.sp,
                  color = Color.Gray
                )
              }
            }
            Text(
              text = "➔",
              color = PitchGreenLight,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(30.dp)) }
    }
  }

  // Edit Team Dialog
  if (showEditDialog && team != null) {
    var nameInput by remember { mutableStateOf(team.name) }
    var ageInput by remember { mutableStateOf(team.ageCategory) }
    var coachInput by remember { mutableStateOf(team.coachName) }
    var formationInput by remember { mutableStateOf(team.defaultFormation) }

    AlertDialog(
      onDismissRequest = { showEditDialog = false },
      title = { Text(s.team, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text(s.teamName) }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = ageInput, onValueChange = { ageInput = it }, label = { Text(s.ageCategory) }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = coachInput, onValueChange = { coachInput = it }, label = { Text(s.coachName) }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = formationInput, onValueChange = { formationInput = it }, label = { Text(s.formation) }, modifier = Modifier.fillMaxWidth())
        }
      },
      confirmButton = {
        Button(
          onClick = {
            coroutineScope.launch {
              viewModel.repository.saveTeam(
                team.copy(
                  name = nameInput.trim(),
                  ageCategory = ageInput.trim(),
                  coachName = coachInput.trim(),
                  defaultFormation = formationInput.trim()
                )
              )
              showEditDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = PitchGreenPrimary)
        ) {
          Text(s.save)
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditDialog = false }) {
          Text(s.cancel)
        }
      }
    )
  }
}

@Composable
fun FormationPill(label: String) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = Color.Black.copy(alpha = 0.65f),
    border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreenLight.copy(alpha = 0.5f))
  ) {
    Text(
      text = label,
      color = Color.White,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}
