package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Football Pitch Colors
val PitchGreenPrimary = Color(0xFF10B981) // Vibrant emerald
val PitchGreenDark = Color(0xFF047857)
val PitchGreenLight = Color(0xFF34D399)
val PitchGreenContainerDark = Color(0xFF064E3B)
val PitchGreenContainerLight = Color(0xFFD1FAE5)

// Secondary Sports Analytics Cyan / Blue
val TacticalCyan = Color(0xFF0EA5E9)
val TacticalCyanLight = Color(0xFF38BDF8)
val TacticalCyanContainerDark = Color(0xFF0C4A6E)

// Tertiary Stadium Gold / Accent
val StadiumAmber = Color(0xFFF59E0B)
val StadiumAmberLight = Color(0xFFFBBF24)
val StadiumAmberContainer = Color(0xFF78350F)

// Functional Status
val StatSuccessGreen = Color(0xFF22C55E)
val StatDangerRed = Color(0xFFEF4444)
val StatWarningYellow = Color(0xFFEAB308)
val StatInfoBlue = Color(0xFF3B82F6)

// Dark Theme Surfaces (Pitch Midnight)
val DarkBackground = Color(0xFF0B111A)
val DarkSurface = Color(0xFF131C2A)
val DarkSurfaceElevated = Color(0xFF1C2738)
val DarkSurfaceHighlight = Color(0xFF253347)
val DarkBorder = Color(0xFF2E3E55)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

// Light Theme Surfaces
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF8FAFC)
val LightBorder = Color(0xFFCBD5E1)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextTertiaryLight = Color(0xFF94A3B8)
