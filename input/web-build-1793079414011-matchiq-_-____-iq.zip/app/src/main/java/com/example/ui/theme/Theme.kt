package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkFootballColorScheme = darkColorScheme(
  primary = PitchGreenLight,
  onPrimary = Color(0xFF003822),
  primaryContainer = PitchGreenContainerDark,
  onPrimaryContainer = Color(0xFFA7F3D0),

  secondary = TacticalCyanLight,
  onSecondary = Color(0xFF003548),
  secondaryContainer = TacticalCyanContainerDark,
  onSecondaryContainer = Color(0xFFBAE6FD),

  tertiary = StadiumAmberLight,
  onTertiary = Color(0xFF452B00),
  tertiaryContainer = StadiumAmberContainer,
  onTertiaryContainer = Color(0xFFFEF3C7),

  background = DarkBackground,
  onBackground = TextPrimaryDark,

  surface = DarkSurface,
  onSurface = TextPrimaryDark,

  surfaceVariant = DarkSurfaceElevated,
  onSurfaceVariant = TextSecondaryDark,

  outline = DarkBorder,
  outlineVariant = DarkSurfaceHighlight,

  error = StatDangerRed,
  onError = Color.White
)

val LightFootballColorScheme = lightColorScheme(
  primary = PitchGreenPrimary,
  onPrimary = Color.White,
  primaryContainer = PitchGreenContainerLight,
  onPrimaryContainer = PitchGreenDark,

  secondary = TacticalCyan,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFE0F2FE),
  onSecondaryContainer = Color(0xFF0369A1),

  tertiary = StadiumAmber,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFFEF3C7),
  onTertiaryContainer = Color(0xFF92400E),

  background = LightBackground,
  onBackground = TextPrimaryLight,

  surface = LightSurface,
  onSurface = TextPrimaryLight,

  surfaceVariant = LightSurfaceElevated,
  onSurfaceVariant = TextSecondaryLight,

  outline = LightBorder,

  error = StatDangerRed,
  onError = Color.White
)

@Composable
fun MatchIQTheme(
  darkTheme: Boolean = true, // default to premium dark tactical mode
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkFootballColorScheme else LightFootballColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
