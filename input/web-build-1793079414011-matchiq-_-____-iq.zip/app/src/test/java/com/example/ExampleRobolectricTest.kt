package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.PlayerMatchStats
import com.example.model.Position
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MATCHIQ", appName)
  }

  @Test
  fun `verify player stats calculations handle zero safely`() {
    val stats = PlayerMatchStats(
      playerId = 1L,
      playerName = "Ahmed Radi",
      shirtNumber = 10,
      position = Position.CM,
      minutesPlayed = 90,
      isStarting = true,
      passesCompleted = 0,
      passesFailed = 0
    )
    assertEquals(0f, stats.passAccuracyPercent, 0.01f)
    assertEquals(0f, stats.dribbleSuccessPercent, 0.01f)
    assertEquals(0f, stats.shotAccuracyPercent, 0.01f)
  }

  @Test
  fun `verify player pass accuracy percentage calculation`() {
    val stats = PlayerMatchStats(
      playerId = 1L,
      playerName = "Ahmed Radi",
      shirtNumber = 10,
      position = Position.CM,
      minutesPlayed = 90,
      isStarting = true,
      passesCompleted = 42,
      passesFailed = 8
    )
    assertEquals(50, stats.totalPasses)
    assertEquals(84.0f, stats.passAccuracyPercent, 0.01f)
  }
}
